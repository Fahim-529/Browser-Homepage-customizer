// Static + live (video) wallpapers. Binary data lives in IndexedDB; settings only hold an asset id.
import * as db from './db.js';
import { state, on, setPath } from './storage.js';
import { $, uid, toast } from './util.js';

export const BUILTIN = 'builtin';
const MAX_IMAGE = 40 * 1024 * 1024, MAX_VIDEO = 300 * 1024 * 1024;
const layer = () => $('#wallpaper');
let el = null, objUrl = null, shownId = undefined, token = 0, slideTimer = null, previewId = null, slideIdx = 0;
const reduceMQ = matchMedia('(prefers-reduced-motion: reduce)');

export const reduceMotion = () => state.settings.general.motion === 'reduce' || (state.settings.general.motion === 'system' && reduceMQ.matches);
const wantsPlay = () => document.visibilityState === 'visible' && !state.settings.wallpaper.paused && !reduceMotion();

function styleVars() {
  const w = state.settings.wallpaper, r = document.documentElement.style;
  r.setProperty('--wp-bright', w.brightness + '%');
  r.setProperty('--wp-blur', w.blur + 'px');
  r.setProperty('--wp-scale', w.blur > 0 ? '1.08' : '1');
  r.setProperty('--wp-opacity', (w.opacity / 100).toFixed(2));
  r.setProperty('--shade-a', (w.overlay / 100).toFixed(2));
  if (el && el.tagName === 'VIDEO') el.playbackRate = w.speed;
}

function syncPlayback() {
  if (!el || el.tagName !== 'VIDEO') return;
  if (wantsPlay()) el.play().catch(() => {}); else el.pause();
}

export async function listWallpapers() {
  const recs = await db.all('wallpaper').catch(() => []);
  return recs.sort((a, b) => a.created - b.created);
}

function clearEl() {
  if (el && el.tagName === 'VIDEO') { el.pause(); el.removeAttribute('src'); el.load(); }
  el = null;
  layer().replaceChildren();
  if (objUrl) { URL.revokeObjectURL(objUrl); objUrl = null; }
}

async function show(id) {
  const my = ++token;
  shownId = id;
  if (id === 'none') { clearEl(); return; }
  let node, url = null, rec = null;
  if (!id || id === BUILTIN) {
    node = document.createElement('img'); node.src = 'assets/wallpaper.jpg'; node.alt = '';
  } else {
    try { rec = await db.get(id); } catch (e) { console.warn(e); }
    if (my !== token) return;
    if (!rec) { toast('Wallpaper file is missing. Using the default.'); if (state.settings.wallpaper.current === id) setPath('wallpaper.current', null); return show(null); }
    url = URL.createObjectURL(rec.blob);
    if (rec.type === 'video') {
      node = document.createElement('video');
      Object.assign(node, { muted: true, loop: true, playsInline: true, controls: false, disablePictureInPicture: true, preload: 'auto' });
      node.setAttribute('muted', ''); node.setAttribute('aria-hidden', 'true'); node.tabIndex = -1;
      if (rec.thumb) { node.poster = URL.createObjectURL(rec.thumb); }
      node.addEventListener('error', () => { toast('This video could not be played. Showing its still frame instead.'); fallbackStill(rec); }, { once: true });
      node.src = url;
    } else { node = document.createElement('img'); node.alt = ''; node.src = url; }
  }
  if (my !== token) { if (url) URL.revokeObjectURL(url); return; }
  const oldUrl = objUrl;
  node.className = 'wp-in';
  layer().replaceChildren(node);
  if (oldUrl) URL.revokeObjectURL(oldUrl);
  objUrl = url; el = node;
  styleVars(); syncPlayback();
}
function fallbackStill(rec) {
  if (!rec.thumb) return show(null);
  const img = document.createElement('img'); img.alt = ''; img.src = URL.createObjectURL(rec.thumb);
  layer().replaceChildren(img); el = img;
}

function slideshowIds(list) { return [BUILTIN, ...list.map((r) => r.id)]; }
async function runSlideshow() {
  clearTimeout(slideTimer);
  const w = state.settings.wallpaper;
  if (!w.slideshow || document.visibilityState === 'hidden' || previewId) return;
  const ids = slideshowIds(await listWallpapers());
  if (ids.length < 2) return;
  slideTimer = setTimeout(async () => { slideIdx = (slideIdx + 1) % ids.length; await show(ids[slideIdx]); runSlideshow(); }, Math.max(5, w.interval) * 1000);
}

export async function preview(id) { previewId = id; clearTimeout(slideTimer); await show(id); }
export async function endPreview(keep) {
  const id = previewId; previewId = null;
  if (keep && id !== null) setPath('wallpaper.current', id === BUILTIN ? null : id); // setPath triggers re-show
  else await show(state.settings.wallpaper.current); runSlideshow();
}
export const isPreviewing = () => previewId !== null;

// ---- upload / validation ----
function thumbFrom(source, w, h) {
  const c = document.createElement('canvas'), s = Math.min(1, 480 / w);
  c.width = Math.max(1, Math.round(w * s)); c.height = Math.max(1, Math.round(h * s));
  c.getContext('2d').drawImage(source, 0, 0, c.width, c.height);
  return new Promise((res) => c.toBlob((b) => res(b), 'image/jpeg', 0.8));
}
function probeVideo(file) {
  return new Promise((resolve, reject) => {
    const url = URL.createObjectURL(file), v = document.createElement('video');
    const done = (err, val) => { clearTimeout(t); URL.revokeObjectURL(url); err ? reject(err) : resolve(val); };
    const t = setTimeout(() => done(new Error('Timed out reading the video. The codec may be unsupported.')), 15000);
    v.muted = true; v.preload = 'auto';
    v.onerror = () => done(new Error('This browser cannot play that video (unsupported codec or corrupt file). Try H.264 MP4 or VP9 WebM.'));
    v.onloadeddata = () => { try { v.currentTime = Math.min(0.5, (v.duration || 1) / 2); } catch (_) {} };
    v.onseeked = async () => { try { done(null, { w: v.videoWidth, h: v.videoHeight, duration: v.duration, thumb: await thumbFrom(v, v.videoWidth, v.videoHeight) }); } catch (e) { done(e); } };
    v.src = url;
  });
}
export async function addWallpaper(file) {
  const ext = (file.name.split('.').pop() || '').toLowerCase();
  const isVideo = ['video/mp4', 'video/webm'].includes(file.type) || (!file.type && ['mp4', 'webm'].includes(ext));
  const isImage = /^image\/(png|jpe?g|webp|gif|avif)$/.test(file.type);
  if (!isVideo && !isImage) throw new Error('Unsupported file type. Use MP4 or WebM video, or PNG, JPEG, WebP, GIF or AVIF images.');
  if (isVideo && file.size > MAX_VIDEO) throw new Error(`Video is too large (max ${MAX_VIDEO / 1048576} MB).`);
  if (isImage && file.size > MAX_IMAGE) throw new Error(`Image is too large (max ${MAX_IMAGE / 1048576} MB).`);
  let meta;
  if (isVideo) meta = await probeVideo(file);
  else {
    let bmp; try { bmp = await createImageBitmap(file); } catch { throw new Error('That image could not be decoded.'); }
    meta = { w: bmp.width, h: bmp.height, thumb: await thumbFrom(bmp, bmp.width, bmp.height) }; bmp.close && bmp.close();
  }
  const rec = { id: uid('wp'), kind: 'wallpaper', type: isVideo ? 'video' : 'image', name: file.name.slice(0, 80), mime: file.type || (isVideo ? 'video/' + ext : ''), size: file.size, created: Date.now(), blob: file, ...meta };
  try { await db.put(rec); } catch (e) { throw new Error(e && e.name === 'QuotaExceededError' ? 'Not enough storage space for this file.' : 'Could not save the file: ' + (e && e.message)); }
  return rec;
}

export async function initWallpaper() {
  styleVars();
  const cur = () => state.settings.wallpaper.current;
  await show(cur());
  on('settings', (e) => {
    const p = e.detail.path;
    if (p === 'wallpaper.current') { if (!isPreviewing()) show(cur()).then(runSlideshow); else previewId = null, show(cur()); }
    else if (p === 'wallpaper.slideshow' || p === 'wallpaper.interval') { if (state.settings.wallpaper.slideshow) runSlideshow(); else { clearTimeout(slideTimer); show(cur()); } }
    else if (p === 'wallpaper.paused' || p === 'general.motion') syncPlayback();
    if (p.startsWith('wallpaper')) styleVars();
  });
  document.addEventListener('visibilitychange', () => { syncPlayback(); if (document.visibilityState === 'visible') runSlideshow(); else clearTimeout(slideTimer); });
  reduceMQ.addEventListener('change', syncPlayback);
  runSlideshow();
}
