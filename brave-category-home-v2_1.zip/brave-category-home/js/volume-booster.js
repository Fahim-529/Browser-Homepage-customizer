// Homepage Volume Booster panel. It controls tabs that are ALREADY being boosted.
// Starting a boost needs the toolbar-icon click on the target tab (Chrome's activeTab/tabCapture rule), so it cannot start from here.
import { state, setPath } from './storage.js';
import { $, h } from './util.js';

let list = [], listening = false;
const send = (m) => chrome.runtime.sendMessage(m).catch(() => null);

export async function fetchList() { const r = await send({ type: 'vb:list' }); list = r && r.ok ? r.list : []; return list; }

export function renderVolumePanel(root, { compact = false } = {}) {
  const draw = () => {
    const rows = list.map((t) => {
      const out = h('output', {}, (t.muted ? 'Muted' : t.percent + '%'));
      const slider = h('input', { type: 'range', min: 0, max: 200, step: 5, value: t.percent, 'aria-label': 'Volume for ' + (t.title || 'tab') });
      slider.addEventListener('input', () => { out.textContent = slider.value + '%'; t.percent = +slider.value; t.muted = false; send({ type: 'vb:set', tabId: t.tabId, percent: t.percent, muted: false }); });
      return h('div', { class: 'vb-row' },
        h('div', { class: 'vb-title', title: t.title }, t.title || 'Tab ' + t.tabId),
        h('div', { class: 'row-gap' },
          h('button', { class: 'icon-btn small', title: t.muted ? 'Unmute' : 'Mute', 'aria-label': 'Mute or unmute', onclick: async () => { await send({ type: 'vb:set', tabId: t.tabId, muted: !t.muted }); await fetchList(); draw(); } }, t.muted ? '🔇' : '🔊'),
          slider, out,
          h('button', { class: 'btn small', onclick: async () => { await send({ type: 'vb:set', tabId: t.tabId, percent: 100, muted: false }); await fetchList(); draw(); } }, '100%'),
          h('button', { class: 'btn small', onclick: async () => { await send({ type: 'vb:stop', tabId: t.tabId }); await fetchList(); draw(); } }, 'Stop')));
    });
    root.replaceChildren(
      rows.length ? h('div', {}, rows) : h('p', { class: 'muted' }, 'No tab is being boosted right now.'),
      h('p', { class: 'muted small' }, 'To boost a tab: open it, click the Brave Category Home toolbar icon, then press Start (0–200%). Browser pages and DRM-protected players may not be capturable.'),
      h('p', { class: 'warn small' }, '⚠ Above 100% audio can distort and may damage hearing at high listening levels.'));
  };
  fetchList().then(draw);
  if (!listening) { listening = true; chrome.runtime.onMessage.addListener((m) => { if (m && m.type === 'vb:changed') fetchList().then(() => document.querySelectorAll('[data-vb]').forEach((el) => el.dispatchEvent(new Event('vb-refresh')))); }); }
  root.dataset.vb = '1';
  root.addEventListener('vb-refresh', draw);
}

export function initVolume() {
  const sec = $('#sec-volume'), body = $('#vbBody'), toggle = $('#vbToggle');
  const apply = () => { sec.classList.toggle('collapsed', state.settings.volume.collapsed); toggle.setAttribute('aria-expanded', String(!state.settings.volume.collapsed)); toggle.textContent = state.settings.volume.collapsed ? '▸' : '▾'; };
  toggle.addEventListener('click', () => { setPath('volume.collapsed', !state.settings.volume.collapsed); apply(); });
  apply();
  renderVolumePanel(body);
}
