// The ONLY place that talks to the network for Weather and News. Everything that comes back is treated as untrusted:
// https only, no credentials, no local/private addresses, no cross-site redirects, size + time limits, strict validation.

const BAD_HOST = /^(localhost|.*\.localhost|.*\.local|.*\.internal|.*\.lan|.*\.home)$/i;
const IPV4 = /^\d{1,3}(\.\d{1,3}){3}$/;
const last = new Map(); // url -> time of last request (simple flood guard)

export function checkUrl(raw) {
  let u;
  try { u = new URL(String(raw)); } catch { throw new Error('That is not a valid web address.'); }
  if (u.protocol !== 'https:') throw new Error('Only secure https:// addresses are allowed.');
  if (u.username || u.password) throw new Error('Addresses with a username or password are not allowed.');
  if (u.port && u.port !== '443') throw new Error('Custom ports are not allowed.');
  if (u.href.length > 2000) throw new Error('That address is too long.');
  const host = u.hostname;
  if (BAD_HOST.test(host) || IPV4.test(host) || host.includes(':') || host.startsWith('[') || !host.includes('.'))
    throw new Error('Local network and IP addresses are blocked for safety.');
  return u;
}

// kind: 'json' | 'xml'. Returns the response body as text (already size-limited).
export async function safeFetch(url, { kind = 'json', maxBytes = 1_000_000, timeout = 10_000, minGap = 4000 } = {}) {
  const u = checkUrl(url);
  const now = Date.now();
  if (last.has(u.href) && now - last.get(u.href) < minGap) throw new Error('Please wait a few seconds before refreshing again.');
  last.set(u.href, now);
  const ctl = new AbortController(), timer = setTimeout(() => ctl.abort(), timeout);
  try {
    const r = await fetch(u.href, {
      credentials: 'omit', cache: 'no-store', redirect: 'follow', referrerPolicy: 'no-referrer', signal: ctl.signal,
      headers: { Accept: kind === 'json' ? 'application/json' : 'application/rss+xml, application/atom+xml, application/xml, text/xml;q=0.9' },
    });
    if (new URL(r.url).origin !== u.origin) throw new Error('Blocked: the server redirected to a different site.');
    if (r.status === 429) throw new Error('Rate limit reached. Try again later.');
    if (!r.ok) throw new Error('The server returned an error (' + r.status + ').');
    const type = (r.headers.get('content-type') || '').toLowerCase();
    if (/html/.test(type)) throw new Error('The server did not return data (got a web page instead).');
    if (kind === 'json' && type && !/json|javascript|text\/plain/.test(type)) throw new Error('Unexpected data type from the server.');
    const len = +r.headers.get('content-length');
    if (len && len > maxBytes) throw new Error('The response is too large and was blocked.');
    const reader = r.body.getReader(), chunks = [];
    let got = 0;
    for (;;) {
      const { done, value } = await reader.read();
      if (done) break;
      got += value.length;
      if (got > maxBytes) { ctl.abort(); throw new Error('The response is too large and was blocked.'); }
      chunks.push(value);
    }
    const buf = new Uint8Array(got); let o = 0;
    for (const c of chunks) { buf.set(c, o); o += c.length; }
    return new TextDecoder('utf-8').decode(buf);
  } catch (e) {
    if (e && e.name === 'AbortError') throw new Error('The request timed out.');
    throw e;
  } finally { clearTimeout(timer); }
}

// ---- sanitizers: used for everything that came from outside ----
const STRIP = /[\u0000-\u0008\u000b\u000c\u000e-\u001f\u007f\u200b-\u200f\u202a-\u202e\u2066-\u2069\ufeff]/g; // control + invisible + bidi-override characters
export const cleanText = (s, max = 200) => String(s == null ? '' : s).replace(STRIP, '').replace(/\s+/g, ' ').trim().slice(0, max);
export function httpsUrl(s) { try { const u = new URL(String(s)); return u.protocol === 'https:' && !u.username && !u.password && u.href.length <= 2000 ? u.href : null; } catch { return null; } }
export const hostOf = (s) => { try { return new URL(s).hostname.replace(/^www\./, ''); } catch { return ''; } };
const num = (v, lo, hi) => { const n = Number(v); if (typeof v === 'boolean' || v === null || v === '' || !Number.isFinite(n) || n < lo || n > hi) throw new Error('Unexpected data from the weather service.'); return n; };
const arr = (a, n, f) => { if (!Array.isArray(a) || a.length < n) throw new Error('Unexpected data from the weather service.'); return a.slice(0, n).map(f); };

// Weather: rebuild a clean object containing ONLY the numbers/dates we display.
export function validateWeather(j) {
  if (!j || typeof j !== 'object' || !j.current || !j.daily) throw new Error('Unexpected response from the weather service.');
  return {
    current: { temperature_2m: num(j.current.temperature_2m, -100, 70), weather_code: num(j.current.weather_code, 0, 99) },
    daily: {
      time: arr(j.daily.time, 5, (t) => { if (!/^\d{4}-\d{2}-\d{2}$/.test(String(t))) throw new Error('Unexpected data from the weather service.'); return String(t); }),
      weather_code: arr(j.daily.weather_code, 5, (v) => num(v, 0, 99)),
      temperature_2m_max: arr(j.daily.temperature_2m_max, 5, (v) => num(v, -100, 70)),
      temperature_2m_min: arr(j.daily.temperature_2m_min, 5, (v) => num(v, -100, 70)),
    },
  };
}
export function validatePlaces(j) {
  return (j && Array.isArray(j.results) ? j.results : []).slice(0, 5).map((r) => {
    const lat = Number(r && r.latitude), lon = Number(r && r.longitude);
    if (!(Math.abs(lat) <= 90) || !(Math.abs(lon) <= 180)) return null;
    return { label: cleanText([r.name, r.admin1, r.country].filter((x) => typeof x === 'string').join(', '), 80), lat: +lat.toFixed(4), lon: +lon.toFixed(4) };
  }).filter((p) => p && p.label);
}

// News: rebuild a clean list. Titles/descriptions are plain text, links and images must be https.
export function cleanNewsItems(list) {
  return (Array.isArray(list) ? list : []).slice(0, 40).map((i) => {
    const link = httpsUrl(i && i.link);
    return link ? { title: cleanText(i.title, 200), link, time: Number.isFinite(i.time) ? i.time : null, desc: cleanText(i.desc, 140), thumb: httpsUrl(i.thumb) } : null;
  }).filter((i) => i && i.title);
}
export function assertSafeXml(xml) {
  if (typeof xml !== 'string' || !xml.trim()) throw new Error('The feed was empty.');
  if (/<!DOCTYPE|<!ENTITY/i.test(xml)) throw new Error('Blocked: the feed contains unsafe XML declarations.'); // stops entity-expansion ("billion laughs") attacks
}
