// Website tiles + add/edit/delete/duplicate/move/icon management.
import * as db from './db.js';
import { state, commitData } from './storage.js';
import { h, uid, dialog, toast, contextMenu, normalizeUrl, fileToIconBlob } from './util.js';

const iconUrls = new Map(); // iconId -> object URL (revoked when the icon is replaced)
export async function customIconUrl(iconId) {
  if (iconUrls.has(iconId)) return iconUrls.get(iconId);
  const rec = await db.get(iconId).catch(() => null);
  if (!rec) return null;
  const u = URL.createObjectURL(rec.blob); iconUrls.set(iconId, u); return u;
}
const hue = (s) => { let n = 0; for (const c of s) n = (n * 31 + c.charCodeAt(0)) % 360; return n; };
export const hostOf = (url) => { try { return new URL(url).hostname; } catch { return ''; } };

export function fillIcon(box, site) {
  box.replaceChildren();
  const letter = () => { box.replaceChildren(h('span', { class: 'fallback', style: { background: `hsl(${hue(site.name)} 55% 45%)` } }, (site.name || '?').trim().charAt(0).toUpperCase())); };
  const useFavicon = () => {
    if (!state.settings.icons.fetchFavicons || !hostOf(site.url)) return letter();
    const img = h('img', { alt: '', loading: 'lazy', draggable: false });
    img.onerror = letter;
    img.onload = () => { if (img.naturalWidth <= 16 && img.naturalHeight <= 16 && img.src.includes('s2/favicons')) { /* tiny default globe: keep */ } };
    img.src = 'https://www.google.com/s2/favicons?sz=128&domain=' + encodeURIComponent(hostOf(site.url));
    box.append(img);
  };
  if (site.iconId) {
    customIconUrl(site.iconId).then((u) => {
      if (!u) return useFavicon();
      const img = h('img', { alt: '', draggable: false, class: 'custom' }); img.onerror = useFavicon; img.src = u; box.replaceChildren(img);
    });
  } else useFavicon();
}

export function makeTile(site) {
  const box = h('div', { class: 'site-icon' });
  fillIcon(box, site);
  return h('a', { class: 'site', href: site.url, draggable: true, dataset: { id: site.id, cat: site.categoryId }, title: site.name + '\n' + site.url, 'aria-label': site.name },
    box, h('div', { class: 'site-name' }, site.name));
}

// ---- data operations ----
export const siteById = (id) => state.websites.find((s) => s.id === id);
export const sitesIn = (catId) => state.websites.filter((s) => s.categoryId === catId);

export function moveSite(id, catId, refId = null, after = false) {
  const i = state.websites.findIndex((s) => s.id === id);
  if (i < 0 || !state.categories.some((c) => c.id === catId)) return false;
  const [site] = state.websites.splice(i, 1);
  site.categoryId = catId;
  let at;
  if (refId && refId !== id && state.websites.some((s) => s.id === refId)) at = state.websites.findIndex((s) => s.id === refId) + (after ? 1 : 0);
  else { const last = state.websites.map((s) => s.categoryId).lastIndexOf(catId); at = last >= 0 ? last + 1 : state.websites.length; }
  state.websites.splice(at, 0, site);
  commitData();
  return true;
}
// Keyboard reorder helpers: dir -1/+1 within category
export function nudgeSite(id, dir) {
  const s = siteById(id); if (!s) return false;
  const list = sitesIn(s.categoryId), i = list.findIndex((x) => x.id === id), j = i + dir;
  if (j < 0 || j >= list.length) return false;
  return moveSite(id, s.categoryId, list[j].id, dir > 0);
}
export function nudgeSiteCategory(id, dir) {
  const s = siteById(id); if (!s) return false;
  const ci = state.categories.findIndex((c) => c.id === s.categoryId), cj = ci + dir;
  if (cj < 0 || cj >= state.categories.length) return false;
  return moveSite(id, state.categories[cj].id);
}

export function deleteSite(site) {
  const idx = state.websites.findIndex((s) => s.id === site.id);
  if (idx < 0) return;
  const [removed] = state.websites.splice(idx, 1);
  commitData();
  toast(`Deleted “${removed.name}”`, { duration: 6000, action: { label: 'Undo', onClick: () => { state.websites.splice(Math.min(idx, state.websites.length), 0, removed); commitData(); } } });
}
export function duplicateSite(site) {
  const i = state.websites.findIndex((s) => s.id === site.id);
  state.websites.splice(i + 1, 0, { ...site, id: uid('s'), name: site.name + ' copy' });
  commitData(); toast('Website duplicated');
}
export async function resetIcon(site) { site.iconId = null; commitData(); toast('Icon reset'); }

export function validateSite({ name, url, categoryId }, selfId) {
  if (!name.trim()) return 'Enter a website name.';
  const norm = normalizeUrl(url);
  if (!norm) return 'Enter a valid web address (http or https).';
  if (state.websites.some((s) => s.id !== selfId && s.categoryId === categoryId && s.url === norm)) return 'This website is already in that category.';
  return null;
}

export function openSiteDialog(site = null, defaultCat = null) {
  const editing = !!site;
  let newBlob = null, removeIcon = false;
  const name = h('input', { type: 'text', maxlength: '60', value: site ? site.name : '', placeholder: 'Name' });
  const url = h('input', { type: 'text', value: site ? site.url : '', placeholder: 'https://example.com' });
  const cat = h('select', {}, state.categories.map((c) => h('option', { value: c.id, selected: c.id === (site ? site.categoryId : defaultCat || state.categories[0].id) }, c.name)));
  const err = h('p', { class: 'form-error', role: 'alert' });
  const prev = h('div', { class: 'site-icon preview' });
  const refreshPrev = () => {
    if (newBlob) { prev.replaceChildren(h('img', { src: URL.createObjectURL(newBlob), alt: '' })); }
    else if (removeIcon || !site || !site.iconId) fillIcon(prev, { name: name.value || '?', url: normalizeUrl(url.value) || '', iconId: null });
    else fillIcon(prev, site);
  };
  const file = h('input', { type: 'file', accept: 'image/*', hidden: true, onchange: async () => {
    const f = file.files[0]; if (!f) return;
    try { newBlob = await fileToIconBlob(f); removeIcon = false; err.textContent = ''; refreshPrev(); } catch (e) { err.textContent = e.message; }
    file.value = '';
  } });
  const body = h('div', { class: 'form' },
    h('label', {}, 'Name', name), h('label', {}, 'URL', url), h('label', {}, 'Category', cat),
    h('div', { class: 'icon-edit' }, prev, h('div', { class: 'col' },
      h('button', { class: 'btn small', type: 'button', onclick: () => file.click() }, 'Upload icon…'),
      h('button', { class: 'btn small', type: 'button', onclick: () => { newBlob = null; removeIcon = true; refreshPrev(); } }, 'Use automatic icon'))),
    file, err);
  refreshPrev();
  url.addEventListener('change', refreshPrev);
  dialog({
    title: editing ? 'Edit website' : 'Add website', body,
    actions: [{ label: 'Cancel' }, { label: editing ? 'Save' : 'Add', kind: 'primary', onClick: async () => {
      const e = validateSite({ name: name.value, url: url.value, categoryId: cat.value }, site && site.id);
      if (e) { err.textContent = e; return false; }
      let iconId = site ? site.iconId : null;
      try {
        if (newBlob) { const id = uid('ic'); await db.put({ id, kind: 'icon', blob: newBlob, created: Date.now() }); iconId = id; }
        else if (removeIcon) iconId = null;
      } catch (ex) { err.textContent = 'Could not save the icon (storage full?).'; return false; }
      const data = { name: name.value.trim(), url: normalizeUrl(url.value), categoryId: cat.value, iconId };
      if (editing) {
        const old = site.iconId; Object.assign(site, data);
        if (old && old !== iconId) { iconUrls.delete(old); db.del(old).catch(() => {}); }
        if (site.categoryId !== cat.value) moveSite(site.id, cat.value);
      } else state.websites.push({ id: uid('s'), ...data });
      commitData();
      toast(editing ? 'Website saved' : 'Website added');
    } }],
  });
}

export function siteMenu(x, y, site) {
  contextMenu(x, y, [
    { label: 'Open in new tab', onClick: () => window.open(site.url, '_blank', 'noopener') },
    { label: 'Edit…', onClick: () => openSiteDialog(site) },
    { label: 'Duplicate', onClick: () => duplicateSite(site) },
    ...state.categories.filter((c) => c.id !== site.categoryId).slice(0, 12).map((c) => ({ label: 'Move to ' + c.name, onClick: () => moveSite(site.id, c.id) })),
    site.iconId && { label: 'Reset custom icon', onClick: () => resetIcon(site) },
    { sep: true },
    { label: 'Delete', danger: true, onClick: () => deleteSite(site) },
  ]);
}

// Remove icon assets nothing references any more (after deletes, imports, resets).
export async function gcIcons() {
  try {
    const used = new Set(state.websites.map((s) => s.iconId).filter(Boolean));
    for (const r of await db.all('icon')) if (!used.has(r.id)) await db.del(r.id);
  } catch (_) {}
}
