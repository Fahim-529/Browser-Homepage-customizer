// Reads a widget FILE (.html). The text is parsed with DOMParser only to read <meta> tags — nothing in it is executed here.
import { cleanText } from './net.js';
import { WIDGET_LIMITS } from './storage.js';

export function parseWidgetFile(text, filename = 'widget.html') {
  if (typeof text !== 'string' || !text.trim()) throw new Error('The file is empty.');
  if (text.length > WIDGET_LIMITS.maxHtml) throw new Error('The widget file is larger than 200 KB.');
  const doc = new DOMParser().parseFromString(text, 'text/html');
  const meta = (n) => { const e = doc.querySelector(`meta[name="${n}"]`); return e ? (e.getAttribute('content') || '').trim() : ''; };
  if (meta('widget-format') !== '1') throw new Error('This is not a Category Home widget file (the <meta name="widget-format" content="1"> line is missing).');
  const base = String(filename).replace(/\.(widget\.)?html?$/i, '');
  const name = cleanText(meta('widget-name') || (doc.title || '') || base, 40) || 'Widget';
  const sizeRaw = meta('widget-size'), hRaw = meta('widget-height');
  const h = hRaw === 'auto' || hRaw === '' ? 0 : Number(hRaw);
  return {
    name, icon: cleanText(meta('widget-icon'), 4),
    size: ['s', 'm', 'l'].includes(sizeRaw) ? sizeRaw : 'm',
    height: h > 0 ? Math.min(600, Math.max(60, Math.round(h))) : 0, // 0 = automatic height
    version: cleanText(meta('widget-version'), 12), html: text,
  };
}
