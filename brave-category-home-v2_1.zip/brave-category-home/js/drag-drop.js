// Native HTML5 drag & drop for websites (within/between categories) and categories (reorder).
// Using real drag events means a plain click still just opens the link — no accidental moves.
import { $, $$ } from './util.js';
import { state } from './storage.js';
import { moveSite } from './websites.js';
import { moveCategory } from './categories.js';

let drag = null; // { kind:'site'|'cat', id }
const MARKS = 'drop-before drop-after drop-into';
const clear = () => $$('.drop-before,.drop-after,.drop-into').forEach((e) => e.classList.remove(...MARKS.split(' ')));

export function initDragDrop() {
  const root = $('#categories');
  root.addEventListener('dragstart', (e) => {
    const site = e.target.closest && e.target.closest('.site');
    const head = e.target.closest && e.target.closest('.cat-head');
    if (site) drag = { kind: 'site', id: site.dataset.id, el: site };
    else if (head) drag = { kind: 'cat', id: head.parentElement.dataset.id, el: head.parentElement };
    else return;
    e.dataTransfer.effectAllowed = 'move';
    e.dataTransfer.setData('text/plain', drag.id);
    requestAnimationFrame(() => drag && drag.el.classList.add('dragging'));
  });
  root.addEventListener('dragover', (e) => {
    if (!drag) return;
    const hit = drag.kind === 'site' ? siteTarget(e) : catTarget(e);
    clear();
    if (!hit) return;
    e.preventDefault(); e.dataTransfer.dropEffect = 'move';
    hit.el.classList.add(hit.mark);
  });
  root.addEventListener('dragleave', (e) => { if (!root.contains(e.relatedTarget)) clear(); });
  root.addEventListener('drop', (e) => {
    if (!drag) return;
    const hit = drag.kind === 'site' ? siteTarget(e) : catTarget(e);
    e.preventDefault(); clear();
    if (hit) { if (drag.kind === 'site') moveSite(drag.id, hit.catId, hit.ref, hit.after); else moveCategory(drag.id, hit.ref, hit.after); }
    drag = null;
  });
  addEventListener('dragend', () => { clear(); drag && drag.el.classList.remove('dragging'); drag = null; });
}

function siteTarget(e) {
  const tile = e.target.closest('.site');
  if (tile && tile.dataset.id !== drag.id) {
    const r = tile.getBoundingClientRect(), after = e.clientX > r.left + r.width / 2;
    return { el: tile, mark: after ? 'drop-after' : 'drop-before', catId: tile.dataset.cat, ref: tile.dataset.id, after };
  }
  if (tile) return null;
  const card = e.target.closest('.cat-card');
  return card ? { el: card, mark: 'drop-into', catId: card.dataset.id, ref: null, after: false } : null;
}
function catTarget(e) {
  const card = e.target.closest('.cat-card');
  if (!card || card.dataset.id === drag.id) return null;
  const r = card.getBoundingClientRect();
  const dx = (e.clientX - (r.left + r.width / 2)) / r.width, dy = (e.clientY - (r.top + r.height / 2)) / r.height;
  const before = Math.abs(dx) > Math.abs(dy) ? dx < 0 : dy < 0;
  return { el: card, mark: before ? 'drop-before' : 'drop-after', ref: card.dataset.id, after: !before };
}
