// News widget — reads public RSS/Atom feeds directly (BBC News, The Verge) or a feed URL you choose.
// Host access is an OPTIONAL permission requested per feed origin, only when you allow it.
import { state, commitWidgets } from './storage.js';
import { h } from './util.js';
import { safeFetch, checkUrl, cleanText, httpsUrl, hostOf, cleanNewsItems, assertSafeXml } from './net.js';

export const FEEDS = {
  technology: { label: 'Technology', url: 'https://feeds.bbci.co.uk/news/technology/rss.xml', source: 'BBC News' },
  ai: { label: 'AI', url: 'https://www.theverge.com/rss/ai-artificial-intelligence/index.xml', source: 'The Verge' },
  business: { label: 'Business', url: 'https://feeds.bbci.co.uk/news/business/rss.xml', source: 'BBC News' },
  science: { label: 'Science', url: 'https://feeds.bbci.co.uk/news/science_and_environment/rss.xml', source: 'BBC News' },
  world: { label: 'World', url: 'https://feeds.bbci.co.uk/news/world/rss.xml', source: 'BBC News' },
  sports: { label: 'Sports', url: 'https://feeds.bbci.co.uk/sport/rss.xml', source: 'BBC Sport' },
};
const TTL = 15 * 60 * 1000;
const origin = (u) => { try { return new URL(u).origin + '/*'; } catch { return null; } };
const safeHttp = httpsUrl; // links and images must be https
const txt = (el, n) => { const e = el.getElementsByTagName(n)[0]; return e ? e.textContent.trim() : ''; };

export function parseFeed(xml) {
  assertSafeXml(xml);
  const doc = new DOMParser().parseFromString(xml, 'text/xml');
  if (doc.getElementsByTagName('parsererror').length) throw new Error('The feed could not be parsed.');
  const chTitle = cleanText((doc.querySelector('channel > title') || doc.querySelector('feed > title') || { textContent: '' }).textContent, 80);
  const nodes = [...doc.getElementsByTagName('item'), ...doc.getElementsByTagName('entry')];
  return { source: chTitle, items: cleanNewsItems(nodes.slice(0, 60).map((n) => {
    const linkEl = n.getElementsByTagName('link')[0];
    const link = safeHttp(linkEl ? (linkEl.getAttribute('href') || linkEl.textContent.trim()) : '');
    const date = new Date(txt(n, 'pubDate') || txt(n, 'published') || txt(n, 'updated'));
    const thumbEl = [...n.getElementsByTagNameNS('*', 'thumbnail'), ...n.getElementsByTagNameNS('*', 'content')].find((e) => e.getAttribute('url'));
    const rawDesc = txt(n, 'description') || txt(n, 'summary');
    const desc = new DOMParser().parseFromString(rawDesc, 'text/html').body.textContent.trim().replace(/\s+/g, ' ');
    return { title: txt(n, 'title'), link, time: isNaN(date) ? null : date.getTime(), desc: desc.length > 140 ? desc.slice(0, 137) + '…' : desc, thumb: thumbEl ? safeHttp(thumbEl.getAttribute('url')) : null };
  })) };
}
const ago = (t) => { const m = Math.round((Date.now() - t) / 60000); return m < 1 ? 'just now' : m < 60 ? m + ' min ago' : m < 1440 ? Math.round(m / 60) + ' h ago' : Math.round(m / 1440) + ' d ago'; };

async function load(feedUrl, force) {
  const key = 'cache:news:' + feedUrl;
  let cached = await chrome.storage.local.get(key).then((o) => o[key]).catch(() => null);
  cached = cached && typeof cached === 'object' ? { at: Number(cached.at) || 0, source: cleanText(cached.source, 80), items: cleanNewsItems(cached.items) } : null; // never trust the cache blindly
  if (!force && cached && Date.now() - cached.at < TTL) return { ...cached, stale: false };
  try {
    const parsed = parseFeed(await safeFetch(feedUrl, { kind: 'xml', maxBytes: 1_500_000 }));
    const rec = { at: Date.now(), ...parsed };
    chrome.storage.local.set({ [key]: rec }).catch(() => {});
    return { ...rec, stale: false };
  } catch (e) { if (cached) return { ...cached, stale: true, error: e.message }; throw e; }
}

export function mount(root, { size }) {
  const c = state.widgets.news;
  const view = h('div', { class: 'news' });
  let alive = true;
  const feedUrl = () => c.customFeed || FEEDS[c.category].url;
  const sourceName = () => c.customFeed ? '' : FEEDS[c.category].source;
  const count = size === 's' ? 3 : size === 'l' ? 8 : 5;

  async function ensurePermission(url) { const o = origin(url); return o ? chrome.permissions.contains({ origins: [o] }) : false; }

  async function refresh(force) {
    view.querySelector('.list')?.replaceChildren(h('p', { class: 'muted pad' }, 'Loading…'));
    const url = feedUrl();
    if (!(await ensurePermission(url))) return draw(null, h('div', { class: 'pad' },
      h('p', {}, `To read this feed, allow Brave Category Home to contact ${new URL(url).hostname}.`),
      h('button', { class: 'btn primary small', onclick: async () => { try { if (await chrome.permissions.request({ origins: [origin(url)] })) refresh(true); } catch (e) { draw(null, h('p', { class: 'form-error' }, 'Permission request failed: ' + e.message)); } } }, 'Allow access'),
      h('p', { class: 'muted small' }, 'Only this site is contacted, and only to download the headlines list.')));
    try {
      const data = await load(url, force);
      if (!alive) return;
      draw(data);
    } catch (e) { if (alive) draw(null, h('div', { class: 'pad' }, h('p', { class: 'form-error' }, /fetch|network/i.test(e.message) ? 'No internet connection, and no saved headlines yet.' : e.message), h('button', { class: 'btn small', onclick: () => refresh(true) }, 'Retry'))); }
  }

  function draw(data, message) {
    const sel = h('select', { 'aria-label': 'News category', onchange: (e) => { c.category = e.target.value; c.customFeed = ''; commitWidgets(); refresh(false); } },
      Object.entries(FEEDS).map(([k, f]) => h('option', { value: k, selected: !c.customFeed && c.category === k }, f.label)),
      c.customFeed ? h('option', { selected: true }, 'Custom feed') : null);
    const bar = h('div', { class: 'row-gap between' }, sel, h('div', { class: 'row-gap' },
      h('button', { class: 'btn small', title: 'Refresh', onclick: () => refresh(true) }, '↻'),
      h('button', { class: 'btn small', title: 'Use your own RSS/Atom feed', onclick: customFeed }, 'Feed…')));
    const body = message || h('ul', { class: 'news-list list' }, data.items.slice(0, count).map((i) => h('li', {},
      h('a', { href: i.link, rel: 'noopener noreferrer', referrerpolicy: 'no-referrer', title: hostOf(i.link) },
        i.thumb && size !== 's' ? h('img', { src: i.thumb, alt: '', loading: 'lazy', referrerpolicy: 'no-referrer' }) : null,
        h('div', {}, h('div', { class: 'ttl' }, i.title), size !== 's' && i.desc ? h('div', { class: 'muted small' }, i.desc) : null,
          h('div', { class: 'muted small' }, [sourceName() || data.source, hostOf(i.link), i.time ? ago(i.time) : null].filter(Boolean).join(' · ')))))));
    view.replaceChildren(bar, body, data && data.stale ? h('p', { class: 'form-error small' }, `Showing saved headlines from ${new Date(data.at).toLocaleTimeString()} (${data.error})`) : null);
  }

  function customFeed() {
    const url = prompt('Enter an RSS or Atom feed URL (https). Leave empty to use the built-in category feeds.', c.customFeed || '');
    if (url === null) return;
    if (url.trim() === '') { c.customFeed = ''; commitWidgets(); return refresh(false); }
    let safe; try { safe = checkUrl(url.trim()).href; } catch (e) { alert(e.message); return; }
    c.customFeed = safe; commitWidgets(); refresh(false);
  }

  root.append(view);
  draw({ items: [], source: '' }, h('p', { class: 'muted pad' }, 'Loading…'));
  refresh(false);
  return { destroy() { alive = false; } };
}
