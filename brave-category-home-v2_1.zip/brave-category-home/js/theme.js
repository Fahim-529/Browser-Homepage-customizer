// Theme presets + CSS-variable application. Everything visual is driven by variables so changes are instant and no re-render is needed.
import { state, on } from './storage.js';

export const THEMES = {
  'glass-dark':    { name: 'Liquid Glass Dark',  text: '#ffffff', primary: '#ffffff', accent: '#7aa7ff', bg: '#0f1722', glass: '#ffffff', border: '#ffffff', bias: 0 },
  'glass-light':   { name: 'Liquid Glass Light', text: '#12161d', primary: '#12161d', accent: '#0a84ff', bg: '#dfe7f2', glass: '#ffffff', border: '#ffffff', bias: 0.3 },
  'midnight':      { name: 'Midnight',           text: '#e8ecff', primary: '#b6c0ff', accent: '#8b9bff', bg: '#070b1a', glass: '#8fa0ff', border: '#a9b6ff', bias: 0 },
  'pure-black':    { name: 'Pure Black',         text: '#f2f2f2', primary: '#ffffff', accent: '#e5e5e5', bg: '#000000', glass: '#ffffff', border: '#ffffff', bias: -0.04 },
  'minimal-white': { name: 'Minimal White',      text: '#111111', primary: '#111111', accent: '#0a84ff', bg: '#f5f5f7', glass: '#ffffff', border: '#cfcfd6', bias: 0.62 },
};
export const themeName = (id) => id === 'custom' ? 'Custom Theme' : (THEMES[id] || THEMES['glass-dark']).name;

export const hexToRgb = (hex) => {
  const m = /^#?([0-9a-f]{6})$/i.exec(hex || '');
  const n = m ? parseInt(m[1], 16) : 0xffffff;
  return `${n >> 16},${(n >> 8) & 255},${n & 255}`;
};

export function currentPalette() {
  const s = state.settings;
  return s.theme === 'custom' ? { ...s.custom, bias: 0 } : (THEMES[s.theme] || THEMES['glass-dark']);
}

export function applyTheme() {
  const s = state.settings, g = s.glass, p = currentPalette(), r = document.documentElement.style;
  const alpha = Math.min(0.95, Math.max(0.02, g.opacity / 100 + p.bias));
  r.setProperty('--text', p.text);
  r.setProperty('--primary', p.primary);
  r.setProperty('--accent', p.accent);
  r.setProperty('--accent-rgb', hexToRgb(p.accent));
  r.setProperty('--bg', p.bg);
  r.setProperty('--bg-rgb', hexToRgb(p.bg));
  r.setProperty('--glass', hexToRgb(p.glass));
  r.setProperty('--glass-a', alpha.toFixed(3));
  r.setProperty('--border', hexToRgb(p.border));
  r.setProperty('--border-a', (g.borderOpacity / 100).toFixed(3));
  r.setProperty('--blur', g.blur + 'px');
  r.setProperty('--radius', g.radius + 'px');
  r.setProperty('--shadow-a', (g.shadow / 100).toFixed(3));
  r.setProperty('--bright', g.brightness + '%');
  const lum = ((parseInt(hexToRgb(p.text).split(',')[0], 10)) > 140) ? 'dark' : 'light'; // light text => dark scheme
  document.documentElement.dataset.scheme = lum;
  document.documentElement.style.colorScheme = lum;
}

export function initTheme() {
  applyTheme();
  on('settings', (e) => { if (/^(theme|custom|glass)/.test((e.detail && e.detail.path) || '')) applyTheme(); });
}
