// Mounts an installed widget FILE inside a sandboxed iframe. The widget's code never runs in the dashboard itself.
import { state, bus, queueSave, WIDGET_LIMITS } from './storage.js';
import { h } from './util.js';

const THEME_VARS = ['text', 'accent', 'accent-rgb', 'bg', 'bg-rgb', 'glass', 'glass-a', 'border', 'border-a'];
const readTheme = () => { const cs = getComputedStyle(document.documentElement), t = {}; for (const k of THEME_VARS) t['' + k] = cs.getPropertyValue('--' + k).trim(); return t; };
const dataSize = (d) => Object.entries(d).reduce((n, [k, v]) => n + k.length + v.length, 0);

export function mount(root, { size, widget }) {
  const frame = h('iframe', { class: 'cw-frame', title: widget.name, sandbox: 'allow-scripts', src: 'sandbox/widget-host.html', referrerpolicy: 'no-referrer', scrolling: 'no' });
  frame.style.height = (widget.height || 200) + 'px';
  root.append(frame);

  const post = (m) => { try { frame.contentWindow.postMessage(m, '*'); } catch (_) {} };
  const live = () => state.widgets.custom.find((c) => c.id === widget.id);

  function onMessage(e) {
    if (e.source !== frame.contentWindow) return; // ignore every other window
    const m = e.data; if (!m || typeof m !== 'object') return;
    const w = live(); if (!w) return;
    if (m.type === 'ready') {
      post({ type: 'init', html: w.html, data: w.data, size, theme: readTheme(), auto: !w.height });
    } else if (m.type === 'resize') {
      const px = Math.min(600, Math.max(60, Math.round(Number(m.height) || 0)));
      if (px) frame.style.height = px + 'px';
    } else if (m.type === 'storage:set') {
      if (typeof m.key !== 'string' || typeof m.value !== 'string' || !/^[\w.-]{1,40}$/.test(m.key)) return;
      const next = { ...w.data, [m.key]: m.value };
      if (dataSize(next) > WIDGET_LIMITS.maxData) return; // each widget gets a small private quota
      w.data = next; queueSave('widgets');
    } else if (m.type === 'storage:remove') {
      if (typeof m.key === 'string' && m.key in w.data) { const n = { ...w.data }; delete n[m.key]; w.data = n; queueSave('widgets'); }
    }
  }
  const onTheme = (e) => { if (/^(theme|custom|glass)/.test(e.detail.path)) requestAnimationFrame(() => post({ type: 'theme', theme: readTheme() })); };
  addEventListener('message', onMessage);
  bus.addEventListener('settings', onTheme);
  return { destroy() { removeEventListener('message', onMessage); bus.removeEventListener('settings', onTheme); frame.remove(); } };
}
