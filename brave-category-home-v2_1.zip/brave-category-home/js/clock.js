// Digital / analog / flip clock. Ticks once per second only when seconds are shown, otherwise once per minute; paused while the tab is hidden.
import { state, on } from './storage.js';
import { $, h } from './util.js';

const FONTS = {
  system: 'system-ui,-apple-system,"Segoe UI",Roboto,sans-serif',
  rounded: 'ui-rounded,"SF Pro Rounded","Nunito","Segoe UI",system-ui,sans-serif',
  serif: 'ui-serif,Georgia,"Times New Roman",serif',
  mono: 'ui-monospace,"SF Mono",Consolas,monospace',
  thin: '"Helvetica Neue","Segoe UI Light","Segoe UI",system-ui,sans-serif',
};
let timer = null, built = '', parts = null;
const pad = (n) => String(n).padStart(2, '0');

function greeting(d) { const hr = d.getHours(); return hr < 5 ? 'Good night' : hr < 12 ? 'Good morning' : hr < 18 ? 'Good afternoon' : 'Good evening'; }
function timeParts(d) {
  const c = state.settings.clock;
  let hr = d.getHours();
  if (c.hour12) hr = hr % 12 || 12;
  return { hh: c.hour12 ? String(hr) : pad(hr), mm: pad(d.getMinutes()), ss: pad(d.getSeconds()) };
}

function build() {
  const c = state.settings.clock, root = $('#clock');
  const key = [c.type, c.seconds].join();
  if (key === built) return;
  built = key; root.replaceChildren(); parts = {};
  if (c.type === 'analog') {
    const NS = 'http://www.w3.org/2000/svg';
    const svg = document.createElementNS(NS, 'svg'); svg.setAttribute('viewBox', '-100 -100 200 200'); svg.setAttribute('class', 'analog'); svg.setAttribute('role', 'img');
    const mk = (tag, attrs) => { const e = document.createElementNS(NS, tag); for (const k in attrs) e.setAttribute(k, attrs[k]); svg.append(e); return e; };
    mk('circle', { r: 96, class: 'face' });
    for (let i = 0; i < 12; i++) { const a = i * Math.PI / 6; mk('line', { x1: Math.sin(a) * 84, y1: -Math.cos(a) * 84, x2: Math.sin(a) * 92, y2: -Math.cos(a) * 92, class: 'tick' }); }
    parts.h = mk('line', { x1: 0, y1: 6, x2: 0, y2: -48, class: 'hand h' });
    parts.m = mk('line', { x1: 0, y1: 8, x2: 0, y2: -72, class: 'hand m' });
    if (c.seconds) parts.s = mk('line', { x1: 0, y1: 12, x2: 0, y2: -80, class: 'hand s' });
    mk('circle', { r: 4, class: 'pin' });
    root.append(svg);
  } else if (c.type === 'flip') {
    const unit = (k) => { const a = h('span', { class: 'flip-digit' }, '0'), b = h('span', { class: 'flip-digit' }, '0'); parts[k] = [a, b]; return h('div', { class: 'flip-unit' }, a, b); };
    root.append(h('div', { class: 'flip' }, unit('hh'), h('span', { class: 'flip-sep' }, ':'), unit('mm'), ...(c.seconds ? [h('span', { class: 'flip-sep' }, ':'), unit('ss')] : [])));
  } else {
    parts.t = h('span', { class: 'digital' }); root.append(parts.t);
  }
}

function paint() {
  const c = state.settings.clock, d = new Date();
  build();
  const t = timeParts(d);
  if (c.type === 'analog') {
    const sec = d.getSeconds(), min = d.getMinutes() + sec / 60, hr = (d.getHours() % 12) + min / 60;
    parts.h.setAttribute('transform', `rotate(${hr * 30})`); parts.m.setAttribute('transform', `rotate(${min * 6})`);
    parts.s && parts.s.setAttribute('transform', `rotate(${sec * 6})`);
    $('#clock svg').setAttribute('aria-label', `${t.hh}:${t.mm}`);
  } else if (c.type === 'flip') {
    for (const k of Object.keys(parts)) {
      const str = pad(+t[k]).slice(-2);
      parts[k].forEach((el, i) => { if (el.textContent !== str[i]) { el.textContent = str[i]; el.classList.remove('flip-go'); void el.offsetWidth; el.classList.add('flip-go'); } });
    }
    if (c.hour12 && t.hh.length === 1) parts.hh[0].textContent = '0';
  } else {
    parts.t.textContent = `${t.hh}:${t.mm}` + (c.seconds ? ':' + t.ss : '') + '';
  }
  const ampm = c.hour12 ? (d.getHours() < 12 ? ' AM' : ' PM') : '';
  $('#clock').dataset.ampm = ampm.trim();
  const dl = $('#dateLine'); dl.hidden = !c.showDate;
  if (c.showDate) dl.textContent = d.toLocaleDateString(undefined, { weekday: 'long', month: 'long', day: 'numeric', year: 'numeric' });
  const g = $('#greeting'); g.hidden = !c.showGreeting;
  if (c.showGreeting) g.textContent = greeting(d);
}

function schedule() {
  clearTimeout(timer);
  if (document.visibilityState === 'hidden') return;
  const c = state.settings.clock, now = Date.now(), step = c.seconds ? 1000 : 60000;
  timer = setTimeout(() => { paint(); schedule(); }, step - (now % step) + 5);
}

function style() {
  const c = state.settings.clock, s = $('#sec-clock').style;
  s.setProperty('--clock-size', c.fontSize + 'px');
  s.setProperty('--clock-font', FONTS[c.font] || FONTS.system);
  s.setProperty('--clock-color', c.color || 'var(--text)');
  s.textAlign = c.align;
  s.alignItems = c.align === 'left' ? 'flex-start' : c.align === 'right' ? 'flex-end' : 'center';
}

export function initClock() {
  style(); paint(); schedule();
  on('settings', (e) => { if (e.detail.path.startsWith('clock')) { style(); paint(); schedule(); } });
  document.addEventListener('visibilitychange', () => { if (document.visibilityState === 'visible') { paint(); schedule(); } else clearTimeout(timer); });
}
