// IndexedDB wrapper for large binary assets (wallpapers) and custom icons.
const DB = 'bch-assets', STORE = 'assets';
let dbp = null;
function open() {
  return dbp || (dbp = new Promise((res, rej) => {
    const r = indexedDB.open(DB, 1);
    r.onupgradeneeded = () => { const s = r.result.createObjectStore(STORE, { keyPath: 'id' }); s.createIndex('kind', 'kind'); };
    r.onsuccess = () => res(r.result);
    r.onerror = () => { dbp = null; rej(r.error); };
  }));
}
async function tx(mode, fn) {
  const d = await open();
  return new Promise((res, rej) => {
    const t = d.transaction(STORE, mode);
    const rq = fn(t.objectStore(STORE));
    t.oncomplete = () => res(rq ? rq.result : undefined);
    t.onerror = () => rej(t.error);
    t.onabort = () => rej(t.error || new Error('Transaction aborted'));
  });
}
export const put = (rec) => tx('readwrite', (s) => s.put(rec));
export const get = (id) => tx('readonly', (s) => s.get(id));
export const del = (id) => tx('readwrite', (s) => s.delete(id));
export const all = (kind) => tx('readonly', (s) => kind ? s.index('kind').getAll(kind) : s.getAll());
export const clear = () => tx('readwrite', (s) => s.clear());
export async function destroy() {
  try { (await open()).close(); } catch (_) {}
  dbp = null;
  await new Promise((res) => { const r = indexedDB.deleteDatabase(DB); r.onsuccess = r.onerror = r.onblocked = () => res(); });
}
