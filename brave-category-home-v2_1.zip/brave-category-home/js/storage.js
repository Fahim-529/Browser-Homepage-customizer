// State, defaults, validation, schema migration (v1 -> v2) and persistence.
import * as db from './db.js';
import { uid, dataURLToBlob } from './util.js';

export const SCHEMA = 2;
export const state = { settings: null, categories: [], websites: [], widgets: null };
export const bus = new EventTarget();
export const emit = (name, detail = {}) => bus.dispatchEvent(new CustomEvent(name, { detail }));
export const on = (name, fn) => bus.addEventListener(name, fn);

const DEFAULT_CATS = [
  ['ai', 'AI', '✦', '#8b7cff', [['ChatGPT', 'https://chatgpt.com/'], ['Claude', 'https://claude.ai/'], ['Gemini', 'https://gemini.google.com/'], ['Perplexity', 'https://www.perplexity.ai/'], ['Grok', 'https://grok.com/'], ['Hugging Face', 'https://huggingface.co/']]],
  ['social', 'Social', '◉', '#ff6b8b', [['YouTube', 'https://www.youtube.com/'], ['Facebook', 'https://www.facebook.com/'], ['Instagram', 'https://www.instagram.com/'], ['X', 'https://x.com/'], ['Reddit', 'https://www.reddit.com/'], ['TikTok', 'https://www.tiktok.com/']]],
  ['study', 'Study', '▣', '#4cc9a6', [['Google Scholar', 'https://scholar.google.com/'], ['Coursera', 'https://www.coursera.org/'], ['Khan Academy', 'https://www.khanacademy.org/'], ['Wikipedia', 'https://www.wikipedia.org/'], ['edX', 'https://www.edx.org/'], ['MIT OpenCourseWare', 'https://ocw.mit.edu/']]],
  ['coding', 'Coding', '</>', '#5aa9ff', [['GitHub', 'https://github.com/'], ['Stack Overflow', 'https://stackoverflow.com/'], ['MDN', 'https://developer.mozilla.org/'], ['LeetCode', 'https://leetcode.com/'], ['CodePen', 'https://codepen.io/'], ['npm', 'https://www.npmjs.com/']]],
  ['editing', 'Editing', '▶', '#ffb454', [['Adobe', 'https://www.adobe.com/'], ['Canva', 'https://www.canva.com/'], ['CapCut', 'https://www.capcut.com/'], ['DaVinci Resolve', 'https://www.blackmagicdesign.com/products/davinciresolve'], ['Envato', 'https://elements.envato.com/'], ['Pexels', 'https://www.pexels.com/']]],
  ['work', 'Work', '◆', '#7bd0ff', [['Gmail', 'https://mail.google.com/'], ['Google Drive', 'https://drive.google.com/'], ['Notion', 'https://www.notion.so/'], ['Trello', 'https://trello.com/'], ['Slack', 'https://slack.com/'], ['LinkedIn', 'https://www.linkedin.com/']]],
  ['fun', 'Fun', '♫', '#ff7ad9', [['Netflix', 'https://www.netflix.com/'], ['Spotify', 'https://open.spotify.com/'], ['Twitch', 'https://www.twitch.tv/'], ['IMDb', 'https://www.imdb.com/'], ['Steam', 'https://store.steampowered.com/'], ['Pinterest', 'https://www.pinterest.com/']]],
  ['tools', 'Tools', '⚙', '#9aa5b1', [['Google', 'https://www.google.com/'], ['Translate', 'https://translate.google.com/'], ['Calendar', 'https://calendar.google.com/'], ['Keep', 'https://keep.google.com/'], ['Speedtest', 'https://www.speedtest.net/'], ['TinyWow', 'https://tinywow.com/']]],
];

export function defaultData() {
  const categories = [], websites = [];
  for (const [id, name, icon, color, sites] of DEFAULT_CATS) {
    categories.push({ id, name, icon, color });
    for (const [n, url] of sites) websites.push({ id: uid('s'), name: n, url, categoryId: id, iconId: null });
  }
  return { categories, websites };
}

export const defaultSettings = () => ({
  general: { motion: 'system' },
  theme: 'glass-dark',
  custom: { primary: '#ffffff', accent: '#7aa7ff', text: '#ffffff', bg: '#0f1722', glass: '#ffffff', border: '#ffffff' },
  glass: { opacity: 12, blur: 24, borderOpacity: 18, radius: 22, shadow: 30, brightness: 100 },
  layout: { order: ['clock', 'search', 'widgets', 'categories', 'volume'], show: { clock: true, search: true, widgets: true, categories: true, volume: true }, maxWidth: 1280, catMin: 300, gap: 24 },
  wallpaper: { current: null, brightness: 100, blur: 0, overlay: 10, opacity: 100, speed: 1, paused: false, slideshow: false, interval: 60 },
  icons: { size: 64, shape: 'rounded-square', radius: 22, spacing: 'normal', background: 'solid', shadow: true, labels: true, labelSize: 11, fetchFavicons: true },
  clock: { type: 'digital', hour12: false, seconds: false, showDate: true, showGreeting: true, fontSize: 96, font: 'system', color: '', align: 'center' },
  search: { engine: 'google', width: 640, height: 52, opacity: 14, blur: 24, radius: 999 },
  idle: { clickExit: true, escExit: true, hideCursor: true, brightness: 100, transition: 'fade', fullscreen: false, shortcut: 'Alt+KeyI' },
  volume: { collapsed: false },
  autohide: { enabled: true, seconds: 30, widgets: false },
  gmail: { show: true, corner: 'bottom-right' },
});
export const defaultWidgets = () => ({
  items: [{ type: 'weather', visible: true, size: 'm' }, { type: 'todo', visible: true, size: 'm' }],
  weather: { label: '', lat: null, lon: null, unit: 'c' },
  news: { category: 'technology', customFeed: '' },
  custom: [], // installed widget files: { id, name, icon, size, height, v, html, data }
});

// Fill missing keys, discard wrong types, keep unknown keys out.
export function mergeTyped(def, val) {
  if (def === null) return (typeof val === 'string' || typeof val === 'number') ? val : null;
  if (Array.isArray(def)) return Array.isArray(val) ? val : def;
  if (typeof def === 'object') {
    const out = {};
    for (const k of Object.keys(def)) out[k] = mergeTyped(def[k], val && typeof val === 'object' ? val[k] : undefined);
    return out;
  }
  return typeof val === typeof def ? val : def;
}

function cleanCategories(cats) {
  const seen = new Set(), out = [];
  for (const c of Array.isArray(cats) ? cats : []) {
    if (!c || typeof c.name !== 'string' || !c.name.trim()) continue;
    let id = typeof c.id === 'string' && c.id ? c.id : uid('c');
    while (seen.has(id)) id = uid('c');
    seen.add(id);
    out.push({ id, name: c.name.trim().slice(0, 40), icon: typeof c.icon === 'string' && c.icon ? c.icon.slice(0, 4) : '•', color: /^#[0-9a-f]{6}$/i.test(c.color) ? c.color : '#7aa7ff' });
  }
  return out;
}
function cleanWebsites(sites, cats) {
  const ids = new Set(cats.map((c) => c.id)), seen = new Set(), out = [];
  for (const s of Array.isArray(sites) ? sites : []) {
    if (!s || typeof s.url !== 'string' || !/^https?:\/\//i.test(s.url)) continue;
    let id = typeof s.id === 'string' && s.id ? s.id : uid('s');
    while (seen.has(id)) id = uid('s');
    seen.add(id);
    // A website whose category vanished is moved to the first category, never dropped.
    out.push({ id, name: String(s.name || s.url).slice(0, 60), url: s.url, categoryId: ids.has(s.categoryId) ? s.categoryId : cats[0].id, iconId: typeof s.iconId === 'string' ? s.iconId : null });
  }
  return out;
}
export const BUILTIN_WIDGETS = ['weather', 'todo', 'news'];
const NEWS_KEYS = ['technology', 'ai', 'business', 'science', 'world', 'sports'];
export const WIDGET_LIMITS = { maxFiles: 12, maxHtml: 200000, maxData: 20000 };

// Installed widget files. Only plain strings/numbers survive; the HTML is never executed here (it runs in a sandboxed iframe).
function cleanCustomWidgets(list) {
  const seen = new Set(), out = [];
  for (const c of Array.isArray(list) ? list : []) {
    if (!c || typeof c.html !== 'string' || !c.html || c.html.length > WIDGET_LIMITS.maxHtml) continue;
    let id = typeof c.id === 'string' && /^w-[a-z0-9]{4,12}$/.test(c.id) ? c.id : uid('w');
    while (seen.has(id)) id = uid('w');
    seen.add(id);
    const data = {};
    let total = 0;
    if (c.data && typeof c.data === 'object') for (const [k, v] of Object.entries(c.data)) {
      if (!/^[\w.-]{1,40}$/.test(k) || typeof v !== 'string') continue;
      total += k.length + v.length; if (total > WIDGET_LIMITS.maxData) break; data[k] = v;
    }
    out.push({ id, name: String(c.name || 'Widget').replace(/[\u0000-\u001f\u202a-\u202e\u2066-\u2069]/g, '').trim().slice(0, 40) || 'Widget',
      icon: typeof c.icon === 'string' ? c.icon.slice(0, 4) : '', size: ['s', 'm', 'l'].includes(c.size) ? c.size : 'm',
      height: c.height > 0 ? Math.min(600, Math.max(60, Math.round(c.height))) : 0, v: Number.isFinite(c.v) ? c.v : 1, html: c.html, data });
    if (out.length >= WIDGET_LIMITS.maxFiles) break;
  }
  return out;
}
export function sanitize(raw) {
  let categories = cleanCategories(raw.categories);
  let websites;
  if (!categories.length) { const d = defaultData(); categories = d.categories; websites = d.websites; }
  else websites = cleanWebsites(raw.websites, categories);
  const settings = mergeTyped(defaultSettings(), raw.settings);
  // order must be a permutation of the known sections
  const known = defaultSettings().layout.order;
  const ord = settings.layout.order.filter((k, i, a) => known.includes(k) && a.indexOf(k) === i);
  known.forEach((k) => { if (!ord.includes(k)) ord.push(k); });
  settings.layout.order = ord;
  const widgets = mergeTyped(defaultWidgets(), raw.widgets);
  widgets.custom = cleanCustomWidgets(raw.widgets && raw.widgets.custom);
  const okType = (t) => BUILTIN_WIDGETS.includes(t) || (typeof t === 'string' && t.startsWith('c:') && widgets.custom.some((c) => 'c:' + c.id === t));
  widgets.items = (Array.isArray(raw.widgets?.items) ? raw.widgets.items : defaultWidgets().items)
    .filter((w, i, a) => w && okType(w.type) && a.findIndex((x) => x && x.type === w.type) === i)
    .map((w) => ({ type: w.type, visible: w.visible !== false, size: ['s', 'm', 'l'].includes(w.size) ? w.size : 'm' }));
  // Defensive clean-up of values that end up in network requests (a restored backup could contain anything).
  const wx = widgets.weather, lat = Number(wx.lat), lon = Number(wx.lon);
  if (wx.lat === null || wx.lon === null || !(Math.abs(lat) <= 90) || !(Math.abs(lon) <= 180) || wx.lat === '' || wx.lon === '') { wx.lat = null; wx.lon = null; } else { wx.lat = lat; wx.lon = lon; }
  wx.label = String(wx.label || '').replace(/[\u0000-\u001f\u202a-\u202e\u2066-\u2069]/g, '').slice(0, 80);
  if (wx.unit !== 'c' && wx.unit !== 'f') wx.unit = 'c';
  if (!NEWS_KEYS.includes(widgets.news.category)) widgets.news.category = 'technology';
  widgets.news.customFeed = /^https:\/\/[^\s]{4,1900}$/.test(widgets.news.customFeed) ? widgets.news.customFeed : '';
  return { settings, categories, websites, widgets };
}

// v1 stored categories[{id,name,icon,sites:[[name,url]]}], settings{position,iconSize,labels,wallpaper(dataURL)}.
async function migrateV1(saved) {
  const out = { settings: {}, widgets: undefined };
  if (Array.isArray(saved.categories) && saved.categories.length && saved.categories.every((c) => c && Array.isArray(c.sites))) {
    out.categories = saved.categories.map((c) => ({ id: c.id, name: c.name, icon: c.icon, color: undefined }));
    out.websites = [];
    for (const c of saved.categories) for (const s of c.sites) if (Array.isArray(s)) out.websites.push({ name: s[0], url: s[1], categoryId: c.id });
    const palette = ['#8b7cff', '#ff6b8b', '#4cc9a6', '#5aa9ff', '#ffb454', '#7bd0ff', '#ff7ad9', '#9aa5b1'];
    out.categories.forEach((c, i) => { c.color = palette[i % palette.length]; });
  }
  const old = saved.settings || {};
  out.settings.icons = {};
  if (Number.isFinite(old.iconSize)) out.settings.icons.size = Math.min(96, Math.max(40, old.iconSize));
  if (typeof old.labels === 'boolean') out.settings.icons.labels = old.labels;
  if (typeof old.wallpaper === 'string' && old.wallpaper.startsWith('data:image/')) {
    try { // move the Base64 wallpaper out of settings into IndexedDB
      const blob = await dataURLToBlob(old.wallpaper);
      await db.put({ id: 'wp-migrated', kind: 'wallpaper', type: 'image', name: 'Previous wallpaper', mime: blob.type, size: blob.size, created: Date.now(), blob, thumb: null });
      out.settings.wallpaper = { current: 'wp-migrated' };
    } catch (e) { console.warn('wallpaper migration failed', e); }
  }
  return out;
}

let dirty = new Set(), timer = null;
export function queueSave(...keys) {
  keys.forEach((k) => dirty.add(k));
  clearTimeout(timer);
  timer = setTimeout(flush, 250);
}
export async function flush() {
  clearTimeout(timer);
  if (!dirty.size) return;
  const payload = { schema: SCHEMA };
  for (const k of dirty) payload[k] = state[k];
  dirty = new Set();
  try { await chrome.storage.local.set(payload); }
  catch (e) { console.error('Saving failed', e); emit('save-error', { error: e }); }
}

export async function loadState() {
  let saved = {};
  try { saved = await chrome.storage.local.get(null); } catch (e) { console.error('storage read failed', e); }
  let raw = saved, migrated = false;
  if (!saved.schema || saved.schema < SCHEMA) {
    try {
      raw = await migrateV1(saved);
      if (saved.categories) await chrome.storage.local.set({ legacyBackup: { categories: saved.categories, at: Date.now() } }).catch(() => {});
      migrated = true;
    } catch (e) { console.error('migration failed', e); raw = {}; }
  }
  Object.assign(state, sanitize(raw));
  if (migrated) { await chrome.storage.local.remove(['activeId']).catch(() => {}); queueSave('settings', 'categories', 'websites', 'widgets'); await flush(); }
  return state;
}

export const getPath = (path, root = state.settings) => path.split('.').reduce((o, k) => (o == null ? o : o[k]), root);
export function setPath(path, value) {
  const keys = path.split('.'), last = keys.pop();
  const o = keys.reduce((a, k) => a[k], state.settings);
  o[last] = value;
  queueSave('settings');
  emit('settings', { path });
}
export function commitData() { queueSave('categories', 'websites'); emit('data'); }
export function commitWidgets() { queueSave('widgets'); emit('widgets'); }

// Removes only this extension's data (chrome.storage.local is private to the extension) and its IndexedDB.
export async function resetEverything() {
  await chrome.storage.local.clear();
  await db.destroy();
}

addEventListener('visibilitychange', () => { if (document.visibilityState === 'hidden') flush(); });
addEventListener('pagehide', flush);
