// Entry point. Each feature initialises independently so one failure can never blank the whole page.
import { loadState, state, on, setPath } from './storage.js';
import { initTheme } from './theme.js';
import { $, toast } from './util.js';

const safe = async (name, fn) => { try { await fn(); } catch (e) { console.error(`[${name}] failed`, e); } };

function applyLayout() {
  const s = state.settings, l = s.layout, ic = s.icons, r = document.documentElement.style;
  l.order.forEach((k, i) => { const el = $('#sec-' + k); if (el) { el.style.order = i; el.hidden = !l.show[k]; } });
  r.setProperty('--maxw', l.maxWidth + 'px'); r.setProperty('--cat-min', l.catMin + 'px'); r.setProperty('--sec-gap', l.gap + 'px');
  r.setProperty('--icon-size', ic.size + 'px'); r.setProperty('--icon-r', (ic.radius / 100).toString());
  r.setProperty('--tile-gap', { compact: '8px', normal: '16px', spacious: '26px' }[ic.spacing] + '');
  r.setProperty('--label-size', ic.labelSize + 'px');
  const b = document.body;
  b.dataset.iconShape = ic.shape; b.dataset.iconBg = ic.background;
  b.classList.toggle('icon-shadow', ic.shadow); b.classList.toggle('hide-labels', !ic.labels);
  b.classList.toggle('reduce-motion', s.general.motion === 'reduce');
  const g = $('#gmailBtn'); g.hidden = !s.gmail.show; g.dataset.corner = s.gmail.corner;
}

async function main() {
  await loadState();
  initTheme();
  applyLayout();
  on('settings', (e) => { if (/^(layout|icons|general|gmail)/.test(e.detail.path)) applyLayout(); });
  on('save-error', () => toast('Could not save (storage may be full).', { duration: 6000 }));

  await safe('wallpaper', async () => (await import('./wallpaper.js')).initWallpaper());
  await safe('clock', async () => (await import('./clock.js')).initClock());
  await safe('search', async () => (await import('./search.js')).initSearch());
  await safe('categories', async () => {
    (await import('./categories.js')).initCategories();
    (await import('./drag-drop.js')).initDragDrop();
    const w = await import('./websites.js'); w.gcIcons();
  });
  await safe('idle', async () => (await import('./idle-mode.js')).initIdle());
  await safe('volume', async () => (await import('./volume-booster.js')).initVolume());
  await safe('widgets', async () => (await import('./widget-manager.js')).initWidgets());
  await safe('autohide', async () => (await import('./autohide.js')).initAutohide());

  let settingsMod = null;
  const openSettings = async (section) => { settingsMod = settingsMod || await import('./settings.js'); settingsMod.openSettings(section); };
  $('#settingsBtn').addEventListener('click', () => safe('settings', () => openSettings()));
  $('#themeBtn').addEventListener('click', () => safe('settings', () => openSettings('appearance')));
  $('#addSiteBtn').addEventListener('click', () => safe('add', async () => (await import('./websites.js')).openSiteDialog()));
  $('#addCatBtn').addEventListener('click', () => safe('addcat', async () => (await import('./categories.js')).openCategoryDialog()));
  $('#fullscreenBtn').addEventListener('click', async () => { try { document.fullscreenElement ? await document.exitFullscreen() : await document.documentElement.requestFullscreen(); } catch (_) { toast('Fullscreen was blocked.'); } });
  $('#addWidgetBtn').addEventListener('click', () => safe('settings', () => openSettings('widgets')));
  $('#wallpaperBtn').addEventListener('click', () => safe('settings', () => openSettings('wallpaper')));
  document.body.classList.add('ready');
}
main().catch((e) => { console.error(e); document.body.classList.add('ready'); });
