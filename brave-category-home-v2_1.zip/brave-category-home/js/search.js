// Google search (default and only engine). Empty queries never navigate.
import { state, on } from './storage.js';
import { $ } from './util.js';

export const googleUrl = (q) => 'https://www.google.com/search?q=' + encodeURIComponent(q);

function style() {
  const s = state.settings.search, st = $('#sec-search').style;
  st.setProperty('--search-w', s.width + 'px');
  st.setProperty('--search-h', s.height + 'px');
  st.setProperty('--search-a', (s.opacity / 100).toFixed(2));
  st.setProperty('--search-blur', s.blur + 'px');
  st.setProperty('--search-radius', s.radius + 'px');
}

export function initSearch() {
  style();
  on('settings', (e) => { if (e.detail.path.startsWith('search')) style(); });
  const form = $('#searchForm'), input = $('#searchInput');
  const go = () => { const q = input.value.trim(); if (q) location.href = googleUrl(q); };
  form.addEventListener('submit', (e) => { e.preventDefault(); go(); });
}
