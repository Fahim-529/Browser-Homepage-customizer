// To-do widget. Tasks live in chrome.storage.local ('todos'); no account, nothing leaves the device.
import { h, uid } from './util.js';

const KEY = 'todos';
let tasks = null;
async function load() {
  if (tasks) return tasks;
  const raw = await chrome.storage.local.get(KEY).then((o) => o[KEY]).catch(() => null);
  tasks = (Array.isArray(raw) ? raw : []).filter((t) => t && typeof t.title === 'string').map((t) => ({ id: t.id || uid('t'), title: t.title.slice(0, 200), desc: typeof t.desc === 'string' ? t.desc : '', created: t.created || Date.now(), due: typeof t.due === 'string' ? t.due : '', done: !!t.done }));
  return tasks;
}
const save = () => chrome.storage.local.set({ [KEY]: tasks }).catch((e) => console.error('todo save failed', e));

export async function mount(root) {
  await load();
  let editing = null, dragId = null;
  const list = h('ul', { class: 'todo-list' });
  const input = h('input', { type: 'text', placeholder: 'Add a task…', maxlength: '200', 'aria-label': 'New task' });
  const due = h('input', { type: 'date', 'aria-label': 'Due date (optional)', class: 'date' });
  const add = () => {
    const t = input.value.trim(); if (!t) return;
    tasks.unshift({ id: uid('t'), title: t, desc: '', created: Date.now(), due: due.value, done: false });
    input.value = ''; due.value = ''; save(); draw(); input.focus();
  };
  input.addEventListener('keydown', (e) => { if (e.key === 'Enter') add(); });
  const clearBtn = h('button', { class: 'btn small', onclick: () => { tasks = tasks.filter((t) => !t.done); save(); draw(); } }, 'Clear completed');
  const count = h('span', { class: 'muted small' });

  function row(t) {
    if (editing === t.id) {
      const title = h('input', { type: 'text', value: t.title, maxlength: '200' }), desc = h('input', { type: 'text', value: t.desc, placeholder: 'Description (optional)' }), d = h('input', { type: 'date', value: t.due });
      const done = () => { const v = title.value.trim(); if (v) { t.title = v; t.desc = desc.value.trim(); t.due = d.value; save(); } editing = null; draw(); };
      title.addEventListener('keydown', (e) => { if (e.key === 'Enter') done(); if (e.key === 'Escape') { editing = null; draw(); } });
      return h('li', { class: 'todo editing' }, h('div', { class: 'col grow' }, title, desc, d), h('button', { class: 'btn small primary', onclick: done }, 'Save'));
    }
    const overdue = t.due && !t.done && t.due < new Date().toISOString().slice(0, 10);
    const li = h('li', { class: 'todo' + (t.done ? ' done' : ''), draggable: true, dataset: { id: t.id } },
      h('input', { type: 'checkbox', checked: t.done, 'aria-label': 'Complete ' + t.title, onchange: (e) => { t.done = e.target.checked; save(); li.classList.toggle('done', t.done); updateMeta(); } }),
      h('div', { class: 'grow' }, h('div', { class: 'ttl' }, t.title), t.desc ? h('div', { class: 'muted small' }, t.desc) : null,
        h('div', { class: 'muted small' + (overdue ? ' overdue' : '') }, 'Added ' + new Date(t.created).toLocaleDateString() + (t.due ? ' · Due ' + new Date(t.due + 'T12:00:00').toLocaleDateString() : ''))),
      h('button', { class: 'icon-btn small', title: 'Edit', 'aria-label': 'Edit task', onclick: () => { editing = t.id; draw(); } }, '✎'),
      h('button', { class: 'icon-btn small', title: 'Delete', 'aria-label': 'Delete task', onclick: () => { tasks = tasks.filter((x) => x !== t); save(); draw(); } }, '×'));
    li.addEventListener('dragstart', (e) => { dragId = t.id; e.dataTransfer.setData('text/plain', t.id); e.dataTransfer.effectAllowed = 'move'; li.classList.add('dragging'); });
    li.addEventListener('dragend', () => { dragId = null; draw(); });
    li.addEventListener('dragover', (e) => { if (dragId && dragId !== t.id) { e.preventDefault(); const r = li.getBoundingClientRect(); li.classList.toggle('drop-before', e.clientY < r.top + r.height / 2); li.classList.toggle('drop-after', e.clientY >= r.top + r.height / 2); } });
    li.addEventListener('dragleave', () => li.classList.remove('drop-before', 'drop-after'));
    li.addEventListener('drop', (e) => {
      e.preventDefault(); if (!dragId || dragId === t.id) return;
      const r = li.getBoundingClientRect(), after = e.clientY >= r.top + r.height / 2;
      const i = tasks.findIndex((x) => x.id === dragId), [m] = tasks.splice(i, 1);
      tasks.splice(tasks.indexOf(t) + (after ? 1 : 0), 0, m); save(); draw();
    });
    return li;
  }
  function updateMeta() { const open = tasks.filter((t) => !t.done).length; count.textContent = `${open} open · ${tasks.length - open} done`; clearBtn.hidden = tasks.length === open; }
  function draw() { list.replaceChildren(...(tasks.length ? tasks.map(row) : [h('li', { class: 'muted small pad' }, 'Nothing to do. Add your first task above.')])); updateMeta(); }
  root.append(h('div', { class: 'todo-wrap' }, h('div', { class: 'row-gap' }, input, due, h('button', { class: 'btn small primary', onclick: add }, 'Add')), list, h('div', { class: 'row-gap between' }, count, clearBtn)));
  draw();
  return {};
}
