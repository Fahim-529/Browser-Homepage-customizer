// Weather widget — Open-Meteo (no API key, no account). Only the location you choose is sent to open-meteo.com.
import { state, commitWidgets } from './storage.js';
import { h } from './util.js';
import { safeFetch, validateWeather, validatePlaces } from './net.js';

const TTL = 30 * 60 * 1000, CACHE_KEY = 'cache:weather';
const CODES = { 0: ['☀️', 'Clear sky'], 1: ['🌤️', 'Mostly clear'], 2: ['⛅', 'Partly cloudy'], 3: ['☁️', 'Overcast'], 45: ['🌫️', 'Fog'], 48: ['🌫️', 'Rime fog'], 51: ['🌦️', 'Light drizzle'], 53: ['🌦️', 'Drizzle'], 55: ['🌧️', 'Heavy drizzle'], 56: ['🌧️', 'Freezing drizzle'], 57: ['🌧️', 'Freezing drizzle'], 61: ['🌧️', 'Light rain'], 63: ['🌧️', 'Rain'], 65: ['🌧️', 'Heavy rain'], 66: ['🌧️', 'Freezing rain'], 67: ['🌧️', 'Freezing rain'], 71: ['🌨️', 'Light snow'], 73: ['🌨️', 'Snow'], 75: ['❄️', 'Heavy snow'], 77: ['🌨️', 'Snow grains'], 80: ['🌦️', 'Rain showers'], 81: ['🌧️', 'Rain showers'], 82: ['⛈️', 'Violent showers'], 85: ['🌨️', 'Snow showers'], 86: ['🌨️', 'Snow showers'], 95: ['⛈️', 'Thunderstorm'], 96: ['⛈️', 'Thunderstorm, hail'], 99: ['⛈️', 'Thunderstorm, hail'] };
const code = (c) => CODES[c] || ['🌡️', 'Unknown'];
const conv = (c, unit) => Math.round(unit === 'f' ? c * 9 / 5 + 32 : c);

const fetchJson = async (url) => { try { return JSON.parse(await safeFetch(url, { kind: 'json', maxBytes: 200000 })); } catch (e) { if (e instanceof SyntaxError) throw new Error('Unexpected response from the weather service.'); throw e; } };
export async function searchCity(q) {
  return validatePlaces(await fetchJson('https://geocoding-api.open-meteo.com/v1/search?count=5&language=en&name=' + encodeURIComponent(String(q).slice(0, 80))));
}
async function loadWeather(c, force) {
  const store = await chrome.storage.local.get(CACHE_KEY).then((o) => o[CACHE_KEY]).catch(() => null);
  const key = c.lat + ',' + c.lon;
  let cached = null;
  try { if (store && store.key === key) cached = { data: validateWeather(store.data), at: Number(store.at) || 0 }; } catch { cached = null; } // never trust the cache blindly
  if (!force && cached && Date.now() - cached.at < TTL) return { data: cached.data, at: cached.at, stale: false };
  try {
    const j = validateWeather(await fetchJson(`https://api.open-meteo.com/v1/forecast?latitude=${Number(c.lat).toFixed(4)}&longitude=${Number(c.lon).toFixed(4)}&current=temperature_2m,weather_code&daily=weather_code,temperature_2m_max,temperature_2m_min&timezone=auto&forecast_days=5`));
    const rec = { key, at: Date.now(), data: j };
    chrome.storage.local.set({ [CACHE_KEY]: rec }).catch(() => {});
    return { data: j, at: rec.at, stale: false };
  } catch (e) {
    if (cached) return { data: cached.data, at: cached.at, stale: true, error: e.message }; // show last known data
    throw e;
  }
}

export function mount(root, { size }) {
  const c = state.widgets.weather;
  const view = h('div', { class: 'weather' });
  root.append(view);
  let alive = true;

  function setupForm(msg) {
    const input = h('input', { type: 'text', placeholder: 'City name…', 'aria-label': 'City', value: '' });
    const results = h('div', { class: 'col' });
    const err = h('p', { class: 'form-error' }, msg || '');
    const go = async () => {
      if (!input.value.trim()) return;
      err.textContent = ''; results.replaceChildren(h('p', { class: 'muted' }, 'Searching…'));
      try {
        const list = await searchCity(input.value.trim());
        if (!list.length) { results.replaceChildren(); err.textContent = 'No matching place found.'; return; }
        results.replaceChildren(...list.map((p) => h('button', { class: 'btn small left', onclick: () => { Object.assign(c, { label: p.label, lat: p.lat, lon: p.lon }); commitWidgets(); refresh(false); } }, p.label)));
      } catch (e) { results.replaceChildren(); err.textContent = e.message.includes('fetch') ? 'No internet connection.' : e.message; }
    };
    const geo = h('button', { class: 'btn small', onclick: () => {
      if (!navigator.geolocation) { err.textContent = 'Location is not available in this browser.'; return; }
      navigator.geolocation.getCurrentPosition(
        (p) => { Object.assign(c, { label: 'My location', lat: +p.coords.latitude.toFixed(2), lon: +p.coords.longitude.toFixed(2) }); commitWidgets(); refresh(false); },
        () => { err.textContent = 'Location permission was denied or is unavailable. Search for a city instead.'; }, { timeout: 10000 });
    } }, '📍 Use my location');
    view.replaceChildren(
      h('div', { class: 'row-gap' }, input, h('button', { class: 'btn small primary', onclick: go }, 'Search')),
      results, err, geo,
      h('p', { class: 'muted small' }, 'Weather data from Open-Meteo. Only the coordinates of your chosen place are sent. Precise location is requested only if you press the button above.'),
      c.lat != null ? h('button', { class: 'btn small', onclick: () => refresh(false) }, 'Cancel') : null);
    input.addEventListener('keydown', (e) => { if (e.key === 'Enter') go(); });
    input.focus();
  }

  async function refresh(force) {
    if (c.lat == null) return setupForm();
    view.replaceChildren(h('p', { class: 'muted pad' }, 'Loading weather…'));
    try {
      const r = await loadWeather(c, force);
      if (!alive) return;
      const d = r.data, [ic, txt] = code(d.current.weather_code), u = c.unit;
      const hi = conv(d.daily.temperature_2m_max[0], u), lo = conv(d.daily.temperature_2m_min[0], u);
      const days = d.daily.time.slice(1, 5).map((t, i) => {
        const dt = new Date(t + 'T12:00:00');
        return h('div', { class: 'fday' }, h('span', { class: 'muted' }, dt.toLocaleDateString(undefined, { weekday: 'short' })), h('span', {}, code(d.daily.weather_code[i + 1])[0]), h('span', {}, `${conv(d.daily.temperature_2m_max[i + 1], u)}° / ${conv(d.daily.temperature_2m_min[i + 1], u)}°`));
      });
      view.replaceChildren(
        h('div', { class: 'w-top' }, h('div', { class: 'w-icon' }, ic), h('div', {}, h('div', { class: 'w-temp' }, conv(d.current.temperature_2m, u) + '°' + u.toUpperCase()), h('div', {}, txt))),
        h('div', { class: 'muted small' }, `${c.label} · H ${hi}° L ${lo}°`),
        size !== 's' ? h('div', { class: 'forecast' }, days) : null,
        r.stale ? h('p', { class: 'form-error small' }, `Showing saved data from ${new Date(r.at).toLocaleTimeString()} (${r.error})`) : null,
        h('div', { class: 'row-gap tools' },
          h('button', { class: 'btn small', title: 'Refresh', onclick: () => refresh(true) }, '↻'),
          h('button', { class: 'btn small', onclick: () => { c.unit = u === 'c' ? 'f' : 'c'; commitWidgets(); refresh(false); } }, '°' + (u === 'c' ? 'F' : 'C')),
          h('button', { class: 'btn small', onclick: () => setupForm() }, 'Change location')));
    } catch (e) {
      if (!alive) return;
      view.replaceChildren(h('p', { class: 'form-error' }, /fetch|network/i.test(e.message) ? 'No internet connection, and no saved weather yet.' : e.message), h('button', { class: 'btn small', onclick: () => refresh(true) }, 'Retry'), h('button', { class: 'btn small', onclick: () => setupForm() }, 'Change location'));
    }
  }
  refresh(false);
  return { destroy() { alive = false; } };
}
