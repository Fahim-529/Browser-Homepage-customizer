// Settings dashboard (docked panel so changes are visible live on the homepage). Loaded lazily on first open.
import * as db from './db.js';
import { state, setPath, getPath, commitData, commitWidgets, queueSave, emit, resetEverything, sanitize, flush } from './storage.js';
import { $, h, dialog, toast, fmtBytes, blobToDataURL, dataURLToBlob } from './util.js';
import { THEMES, themeName } from './theme.js';
import { listWallpapers, addWallpaper, preview, endPreview, isPreviewing, BUILTIN } from './wallpaper.js';
import { openCategoryDialog, deleteCategoryFlow, nudgeCategory } from './categories.js';
import { openSiteDialog, duplicateSite, deleteSite, nudgeSite, sitesIn } from './websites.js';
import { WIDGETS, SIZES, addWidget, removeWidget, setVisible, setSize, moveWidget, defOf, customList, installWidgetText, uninstallCustom } from './widget-manager.js';
import { comboFromEvent, prettyCombo } from './idle-mode.js';
import { renderVolumePanel } from './volume-booster.js';
import { FEEDS } from './news.js';

const SECTIONS = [['general', 'General'], ['layout', 'Layout'], ['appearance', 'Appearance'], ['wallpaper', 'Wallpaper'], ['icons', 'Icons'], ['categories', 'Categories'], ['websites', 'Websites'], ['clock', 'Clock'], ['search', 'Search'], ['widgets', 'Widgets'], ['volume', 'Volume Booster'], ['backup', 'Backup & Restore'], ['advanced', 'Advanced']];
let panel, content, navBtns, current = 'general';

// ---- declarative controls bound to settings paths (live: every change applies immediately) ----
function ctl(c) {
  const val = getPath(c.path);
  let input;
  if (c.t === 'range') {
    const out = h('output', {}, (c.fmt ? c.fmt(val) : val) + (c.unit || ''));
    input = h('div', { class: 'row-gap' }, h('input', { type: 'range', min: c.min, max: c.max, step: c.step || 1, value: val, 'aria-label': c.label, oninput: (e) => { const v = +e.target.value; out.textContent = (c.fmt ? c.fmt(v) : v) + (c.unit || ''); setPath(c.path, v); } }), out);
  } else if (c.t === 'toggle') {
    input = h('label', { class: 'switch' }, h('input', { type: 'checkbox', checked: !!val, 'aria-label': c.label, onchange: (e) => { setPath(c.path, e.target.checked); c.after && c.after(); } }), h('span'));
  } else if (c.t === 'select') {
    input = h('select', { 'aria-label': c.label, onchange: (e) => { const v = c.num ? +e.target.value : e.target.value === 'true' ? true : e.target.value === 'false' ? false : e.target.value; setPath(c.path, v); c.after && c.after(); } }, c.opts.map(([v, l]) => h('option', { value: String(v), selected: String(v) === String(val) }, l)));
  } else if (c.t === 'color') {
    input = h('div', { class: 'row-gap' }, h('input', { type: 'color', value: val || c.fallback || '#ffffff', 'aria-label': c.label, oninput: (e) => setPath(c.path, e.target.value) }), c.clearable ? h('button', { class: 'btn small', onclick: () => { setPath(c.path, ''); show(current); } }, 'Theme default') : null);
  }
  return h('div', { class: 'row' }, h('div', { class: 'lbl' }, h('b', {}, c.label), c.hint ? h('small', {}, c.hint) : null), input);
}
const group = (title, ...kids) => h('div', { class: 'group' }, title ? h('h4', {}, title) : null, ...kids);
const note = (t, cls = '') => h('p', { class: 'muted small ' + cls }, t);

// ---- sections ----
const S = {
  general() {
    const sc = h('button', { class: 'btn', onclick: () => {
      sc.textContent = 'Press the new shortcut…';
      const on = (e) => { e.preventDefault(); e.stopPropagation(); if (e.key === 'Escape') { sc.textContent = prettyCombo(state.settings.idle.shortcut); removeEventListener('keydown', on, true); return; }
        const c = comboFromEvent(e); if (!c) return; setPath('idle.shortcut', c); sc.textContent = prettyCombo(c); removeEventListener('keydown', on, true); };
      addEventListener('keydown', on, true);
    } }, prettyCombo(state.settings.idle.shortcut));
    return [
      group('Idle Mode', note('Hides this interface so only the wallpaper shows. It cannot hide Brave’s own toolbar or tabs; enable “Browser fullscreen” for that.'),
        ctl({ t: 'toggle', path: 'idle.escExit', label: 'Press Escape to exit' }), ctl({ t: 'toggle', path: 'idle.clickExit', label: 'Click the screen to exit' }),
        ctl({ t: 'toggle', path: 'idle.hideCursor', label: 'Hide the cursor when idle' }),
        ctl({ t: 'toggle', path: 'idle.fullscreen', label: 'Browser fullscreen', hint: 'Uses the Fullscreen API; starts only from a click or the shortcut.' }),
        ctl({ t: 'select', path: 'idle.transition', label: 'Transition', opts: [['fade', 'Fade'], ['zoom', 'Zoom'], ['none', 'None']] }),
        ctl({ t: 'range', path: 'idle.brightness', label: 'Wallpaper brightness in Idle Mode', min: 20, max: 100, unit: '%' }),
        h('div', { class: 'row' }, h('div', { class: 'lbl' }, h('b', {}, 'Keyboard shortcut'), h('small', {}, 'Toggles Idle Mode. Must include Ctrl, Alt, Shift or Meta (or be an F-key).')), sc)),
      group('Motion', ctl({ t: 'select', path: 'general.motion', label: 'Animations & video', hint: '“Follow system” respects your reduced-motion setting.', opts: [['system', 'Follow system'], ['reduce', 'Always reduce']] })),
    ];
  },
  layout() {
    const names = { clock: 'Clock & date', search: 'Search bar', widgets: 'Widgets', categories: 'Websites', volume: 'Volume Booster' };
    const l = state.settings.layout;
    const rows = l.order.map((k, i) => h('div', { class: 'row' }, h('div', { class: 'lbl' }, h('b', {}, names[k])),
      h('div', { class: 'row-gap' },
        h('button', { class: 'btn small', disabled: i === 0, 'aria-label': 'Move up', onclick: () => { const o = [...l.order]; [o[i - 1], o[i]] = [o[i], o[i - 1]]; setPath('layout.order', o); show('layout'); } }, '↑'),
        h('button', { class: 'btn small', disabled: i === l.order.length - 1, 'aria-label': 'Move down', onclick: () => { const o = [...l.order]; [o[i + 1], o[i]] = [o[i], o[i + 1]]; setPath('layout.order', o); show('layout'); } }, '↓'),
        h('label', { class: 'switch' }, h('input', { type: 'checkbox', checked: l.show[k], 'aria-label': 'Show ' + names[k], onchange: (e) => setPath('layout.show.' + k, e.target.checked) }), h('span')))));
    return [group('Section order & visibility', note('Dashboard Grid is the layout; order the sections as you like.'), ...rows),
      group('Auto-hide categories', note('After a period without using the page, your website categories fade out. Move the mouse, click or press a key to bring them back. Nothing hides while a dialog, menu or Settings is open.'),
        ctl({ t: 'toggle', path: 'autohide.enabled', label: 'Hide categories when not in use' }),
        ctl({ t: 'range', path: 'autohide.seconds', label: 'Hide after', min: 5, max: 300, step: 5, unit: ' s' }),
        ctl({ t: 'toggle', path: 'autohide.widgets', label: 'Also hide widgets' })),
      group('Gmail button', note('A small fixed button that opens Gmail. It stays visible even when categories are hidden.'),
        ctl({ t: 'toggle', path: 'gmail.show', label: 'Show Gmail button' }),
        ctl({ t: 'select', path: 'gmail.corner', label: 'Position', opts: [['bottom-right', 'Bottom right'], ['bottom-left', 'Bottom left']] })),
      group('Spacing', ctl({ t: 'range', path: 'layout.maxWidth', label: 'Content width', min: 800, max: 1800, step: 20, unit: 'px' }), ctl({ t: 'range', path: 'layout.catMin', label: 'Minimum category card width', min: 220, max: 520, step: 10, unit: 'px' }), ctl({ t: 'range', path: 'layout.gap', label: 'Gap between sections', min: 8, max: 48, unit: 'px' }))];
  },
  appearance() {
    const t = state.settings.theme;
    const presets = h('div', { class: 'presets' }, [...Object.entries(THEMES).map(([id, th]) => [id, th.name, th]), ['custom', 'Custom Theme', state.settings.custom]].map(([id, name, th]) =>
      h('button', { class: 'preset' + (t === id ? ' active' : ''), onclick: () => { setPath('theme', id); show('appearance'); }, style: { '--pb': th.bg, '--pa': th.accent, '--pt': th.text } }, h('span', { class: 'swatch' }), name)));
    const out = [group('Theme', presets)];
    if (t === 'custom') out.push(group('Custom theme', ...[['primary', 'Primary color'], ['accent', 'Accent color'], ['text', 'Text color'], ['bg', 'Background color'], ['glass', 'Glass color'], ['border', 'Border color']].map(([k, l]) => ctl({ t: 'color', path: 'custom.' + k, label: l }))));
    out.push(group('Liquid Glass', ctl({ t: 'range', path: 'glass.opacity', label: 'Glass opacity', min: 0, max: 60, unit: '%' }), ctl({ t: 'range', path: 'glass.blur', label: 'Blur intensity', min: 0, max: 60, unit: 'px' }),
      ctl({ t: 'range', path: 'glass.borderOpacity', label: 'Border opacity', min: 0, max: 80, unit: '%' }), ctl({ t: 'range', path: 'glass.radius', label: 'Corner radius', min: 0, max: 40, unit: 'px' }),
      ctl({ t: 'range', path: 'glass.shadow', label: 'Shadow intensity', min: 0, max: 80, unit: '%' }), ctl({ t: 'range', path: 'glass.brightness', label: 'Glass brightness', min: 60, max: 160, unit: '%' }),
      h('button', { class: 'btn', onclick: () => { const d = sanitize({}).settings; for (const k of ['theme', 'custom', 'glass']) { state.settings[k] = d[k]; } queueSave('settings'); emit('settings', { path: 'theme' }); show('appearance'); toast('Default theme restored'); } }, 'Restore default theme')));
    return out;
  },
  wallpaper() {
    const grid = h('div', { class: 'wp-grid' }), bar = h('div', { class: 'preview-bar', hidden: true });
    const file = h('input', { type: 'file', accept: 'video/mp4,video/webm,image/png,image/jpeg,image/webp,image/gif,image/avif,.mp4,.webm', hidden: true, multiple: true, onchange: async () => {
      for (const f of file.files) { try { const r = await addWallpaper(f); toast(`Added “${r.name}”`); } catch (e) { toast(e.message, { duration: 6000 }); } }
      file.value = ''; fill();
    } });
    const tiles = [];
    async function fill() {
      const list = await listWallpapers(), cur = state.settings.wallpaper.current || BUILTIN;
      const tile = (id, name, thumbUrl, kind, removable) => h('div', { class: 'wp-tile' + (cur === id ? ' active' : '') },
        h('button', { class: 'wp-thumb', style: thumbUrl ? { backgroundImage: `url(${thumbUrl})` } : {}, title: 'Use this wallpaper', onclick: async () => { if (isPreviewing()) await endPreview(false); setPath('wallpaper.current', id === BUILTIN ? null : id); fill(); } }, id === 'none' ? 'Solid' : '', kind === 'video' ? h('span', { class: 'badge' }, '▶ live') : null),
        h('div', { class: 'wp-meta' }, h('span', { title: name }, name),
          id !== 'none' ? h('button', { class: 'btn small', onclick: async () => { await preview(id); bar.hidden = false; barText.textContent = 'Previewing “' + name + '”'; } }, 'Preview') : null,
          removable ? h('button', { class: 'btn small danger', onclick: async () => { if (!confirm(`Remove “${name}”?`)) return; await db.del(id); if (state.settings.wallpaper.current === id) setPath('wallpaper.current', null); fill(); } }, '✕') : null));
      tiles.forEach((u) => URL.revokeObjectURL(u)); tiles.length = 0;
      grid.replaceChildren(tile(BUILTIN, 'Default', 'assets/wallpaper.jpg', 'image', false), tile('none', 'Solid theme color', null, 'image', false),
        ...list.map((r) => { const u = r.thumb ? URL.createObjectURL(r.thumb) : null; if (u) tiles.push(u); return tile(r.id, r.name, u, r.type, true); }));
    }
    const barText = h('span');
    bar.append(barText, h('button', { class: 'btn small primary', onclick: async () => { await endPreview(true); bar.hidden = true; fill(); } }, 'Keep'), h('button', { class: 'btn small', onclick: async () => { await endPreview(false); bar.hidden = true; } }, 'Cancel'));
    fill();
    return [group('Library', note('MP4/WebM video (H.264, VP9 or AV1 depending on your browser) or PNG/JPEG/WebP/GIF/AVIF. Files stay on this device (IndexedDB). Videos up to 300 MB; images up to 40 MB.'),
      h('div', { class: 'row-gap' }, h('button', { class: 'btn primary', onclick: () => file.click() }, 'Upload wallpaper…')), file, bar, grid),
    group('Adjust', ctl({ t: 'range', path: 'wallpaper.brightness', label: 'Brightness', min: 20, max: 150, unit: '%' }), ctl({ t: 'range', path: 'wallpaper.blur', label: 'Blur', min: 0, max: 30, unit: 'px' }),
      ctl({ t: 'range', path: 'wallpaper.overlay', label: 'Overlay darkness', min: 0, max: 80, unit: '%' }), ctl({ t: 'range', path: 'wallpaper.opacity', label: 'Wallpaper opacity', min: 10, max: 100, unit: '%' }),
      ctl({ t: 'range', path: 'wallpaper.speed', label: 'Video playback speed', min: 0.25, max: 2, step: 0.25, unit: '×' }),
      ctl({ t: 'toggle', path: 'wallpaper.paused', label: 'Pause animation', hint: 'Videos also pause automatically while this tab is hidden.', after: () => emit('settings', { path: 'wallpaper.paused' }) })),
    group('Slideshow', ctl({ t: 'toggle', path: 'wallpaper.slideshow', label: 'Rotate through my wallpapers' }), ctl({ t: 'range', path: 'wallpaper.interval', label: 'Change every', min: 10, max: 600, step: 10, unit: ' s' }))];
  },
  icons() {
    return [group('Shape & size', ctl({ t: 'range', path: 'icons.size', label: 'Icon size', min: 40, max: 96, unit: 'px' }),
      ctl({ t: 'select', path: 'icons.shape', label: 'Shape', opts: [['rounded-square', 'Rounded square'], ['circle', 'Circle'], ['square', 'Square']] }),
      ctl({ t: 'range', path: 'icons.radius', label: 'Corner radius', hint: 'Applies to rounded squares (iOS ≈ 22%).', min: 0, max: 50, unit: '%' }),
      ctl({ t: 'select', path: 'icons.spacing', label: 'Spacing', opts: [['compact', 'Compact'], ['normal', 'Normal'], ['spacious', 'Spacious']] })),
    group('Look', ctl({ t: 'select', path: 'icons.background', label: 'Background', opts: [['transparent', 'Transparent'], ['solid', 'Solid'], ['glass', 'Liquid Glass']] }), ctl({ t: 'toggle', path: 'icons.shadow', label: 'Shadow' }),
      ctl({ t: 'toggle', path: 'icons.labels', label: 'Show website names' }), ctl({ t: 'range', path: 'icons.labelSize', label: 'Name size', min: 9, max: 16, unit: 'px' })),
    group('Source', ctl({ t: 'toggle', path: 'icons.fetchFavicons', label: 'Fetch favicons automatically', hint: 'Uses Google’s favicon service (sends each site’s domain to Google). Turn off for letter icons; custom uploaded icons always work.' }))];
  },
  categories() {
    const rows = state.categories.map((c, i) => h('div', { class: 'row' }, h('div', { class: 'lbl' }, h('b', {}, c.icon + '  ' + c.name), h('small', {}, sitesIn(c.id).length + ' websites')),
      h('div', { class: 'row-gap' }, h('button', { class: 'btn small', disabled: i === 0, 'aria-label': 'Move up', onclick: () => { nudgeCategory(c.id, -1); show('categories'); } }, '↑'), h('button', { class: 'btn small', disabled: i === state.categories.length - 1, 'aria-label': 'Move down', onclick: () => { nudgeCategory(c.id, 1); show('categories'); } }, '↓'),
        h('button', { class: 'btn small', onclick: () => openCategoryDialog(c) }, 'Edit'), h('button', { class: 'btn small danger', onclick: () => deleteCategoryFlow(c) }, 'Delete'))));
    return [group('Categories', note('You can also drag category headers on the homepage.'), h('button', { class: 'btn primary', onclick: () => openCategoryDialog() }, '+ New category'), ...rows)];
  },
  websites() {
    return [h('button', { class: 'btn primary', onclick: () => openSiteDialog() }, '+ Add website'), ...state.categories.map((c) => group(c.icon + ' ' + c.name, ...sitesIn(c.id).map((s) =>
      h('div', { class: 'row' }, h('div', { class: 'lbl' }, h('b', {}, s.name), h('small', {}, s.url)),
        h('div', { class: 'row-gap' }, h('button', { class: 'btn small', onclick: () => openSiteDialog(s) }, 'Edit'), h('button', { class: 'btn small', onclick: () => duplicateSite(s) }, 'Duplicate'), h('button', { class: 'btn small danger', onclick: () => deleteSite(s) }, 'Delete'))))))];
  },
  clock() {
    return [group('Style', ctl({ t: 'select', path: 'clock.type', label: 'Clock style', opts: [['digital', 'Digital'], ['analog', 'Analog'], ['flip', 'Flip']] }),
      ctl({ t: 'select', path: 'clock.hour12', label: 'Time format', opts: [['false', '24-hour'], ['true', '12-hour']] }), ctl({ t: 'toggle', path: 'clock.seconds', label: 'Show seconds' }),
      ctl({ t: 'toggle', path: 'clock.showDate', label: 'Show date' }), ctl({ t: 'toggle', path: 'clock.showGreeting', label: 'Show greeting' })),
    group('Typography', ctl({ t: 'range', path: 'clock.fontSize', label: 'Size', min: 40, max: 200, unit: 'px' }),
      ctl({ t: 'select', path: 'clock.font', label: 'Font', opts: [['system', 'System'], ['rounded', 'Rounded'], ['serif', 'Serif'], ['mono', 'Monospace'], ['thin', 'Light']] }),
      ctl({ t: 'color', path: 'clock.color', label: 'Text color', clearable: true }), ctl({ t: 'select', path: 'clock.align', label: 'Alignment', opts: [['left', 'Left'], ['center', 'Center'], ['right', 'Right']] })),
    note('Uses your system time zone. Position: see Layout.')];
  },
  search() {
    return [group('Google search', note('Google is the search engine. Pressing Enter or clicking the search button opens Google results; empty searches do nothing.'),
      ctl({ t: 'range', path: 'search.width', label: 'Width', min: 320, max: 1000, step: 10, unit: 'px' }), ctl({ t: 'range', path: 'search.height', label: 'Height', min: 36, max: 80, unit: 'px' }),
      ctl({ t: 'range', path: 'search.opacity', label: 'Opacity', min: 0, max: 80, unit: '%' }), ctl({ t: 'range', path: 'search.blur', label: 'Blur', min: 0, max: 50, unit: 'px' }),
      ctl({ t: 'range', path: 'search.radius', label: 'Corner radius', min: 0, max: 40, unit: 'px', fmt: (v) => (v >= 40 ? 'Pill' : v) }),
      note('Position: see Layout. A microphone button is intentionally omitted: Brave does not ship Google’s speech service, so it could not work.'))];
  },
  widgets() {
    const items = state.widgets.items, builtin = Object.keys(WIDGETS), custom = customList().map((c) => 'c:' + c.id);
    const avail = [...builtin, ...custom].filter((t) => !items.some((w) => w.type === t));
    const err = h('p', { class: 'form-error', role: 'alert' });
    const file = h('input', { type: 'file', accept: '.html,.htm,text/html', hidden: true, 'aria-label': 'Choose a widget file', onchange: async (e) => {
      const f = e.target.files[0]; e.target.value = ''; err.textContent = ''; if (!f) return;
      try {
        if (f.size > 200000) throw new Error('The widget file is larger than 200 KB.');
        const text = await f.text();
        const { parseWidgetFile } = await import('./widget-file.js'), p = parseWidgetFile(text, f.name);
        dialog({ title: 'Install widget “' + p.name + '”?', body: h('div', { class: 'form' },
          h('p', {}, 'This widget runs in an isolated sandbox. It cannot see your tabs, websites, settings or other widgets, and it has no internet access. It can only draw inside its own box and keep a small amount of its own data (20 KB).'),
          h('p', { class: 'muted small' }, 'Only install widget files from sources you trust.')),
          actions: [{ label: 'Cancel' }, { label: 'Install & add', kind: 'primary', onClick: () => {
            try { const r = installWidgetText(text, f.name); toast(r.updated ? 'Widget updated' : 'Widget installed'); show('widgets'); } catch (x) { err.textContent = x.message; }
          } }] });
      } catch (x) { err.textContent = x.message; }
    } });
    const title = (t) => defOf(t).title;
    return [group('Active widgets', ...(items.length ? items.map((w, i) => h('div', { class: 'row' }, h('div', { class: 'lbl' }, h('b', {}, title(w.type)), h('small', {}, (w.type.startsWith('c:') ? 'Installed file · ' : '') + (w.visible ? 'Visible' : 'Hidden'))),
      h('div', { class: 'row-gap wrap' }, h('button', { class: 'btn small', disabled: i === 0, onclick: () => { moveWidget(w.type, -1); show('widgets'); } }, '↑'), h('button', { class: 'btn small', disabled: i === items.length - 1, onclick: () => { moveWidget(w.type, 1); show('widgets'); } }, '↓'),
        h('select', { 'aria-label': 'Size', onchange: (e) => setSize(w.type, e.target.value) }, Object.entries(SIZES).map(([k, l]) => h('option', { value: k, selected: w.size === k }, l))),
        h('button', { class: 'btn small', onclick: () => { setVisible(w.type, !w.visible); show('widgets'); } }, w.visible ? 'Hide' : 'Show'),
        h('button', { class: 'btn small danger', onclick: () => { removeWidget(w.type); show('widgets'); } }, 'Remove')))) : [note('No widgets added.')])),
    group('Available widgets', ...(avail.length ? avail.map((t) => h('div', { class: 'row' }, h('div', { class: 'lbl' }, h('b', {}, title(t)), t.startsWith('c:') ? h('small', {}, 'Installed file') : null),
      h('div', { class: 'row-gap' },
        t.startsWith('c:') ? h('button', { class: 'btn small danger', onclick: () => dialog({ title: 'Uninstall widget?', body: h('p', {}, '“' + defOf(t).title + '” and its saved data will be deleted.'), actions: [{ label: 'Cancel' }, { label: 'Uninstall', kind: 'danger', onClick: () => { uninstallCustom(t); show('widgets'); } }] }) }, 'Uninstall') : null,
        h('button', { class: 'btn small primary', onclick: () => { addWidget(t); show('widgets'); } }, '+ Add')))) : [note('All widgets are added.')])),
    group('Install a widget file', note('Add your own widget (for example a timer) without rebuilding the extension. Choose a widget .html file — see the widgets folder in the extension for the timer and a template. Installing a file with the same name updates it.'),
      file, h('button', { class: 'btn primary', onclick: () => file.click() }, 'Choose widget file…'), err),
    note('Weather: Open-Meteo (no key). News: BBC News / The Verge RSS, or your own https feed; access is requested per site only when you allow it. To-do: stored only on this device. All downloaded data is validated and cleaned before it is shown. Installed widget files run in a sandbox with no network access.')];
  },
  volume() {
    const box = h('div');
    renderVolumePanel(box);
    return [group('Volume Booster (per tab, 0–200%)',
      note('Works on one tab at a time via Brave/Chromium tab capture. Start it from the toolbar icon on the tab you want to boost (this is a browser rule: capture needs that click). It cannot boost every tab at once, cannot capture browser pages, and DRM-protected video may stay silent.'),
      ctl({ t: 'toggle', path: 'layout.show.volume', label: 'Show panel on the homepage' }), ctl({ t: 'toggle', path: 'volume.collapsed', label: 'Start collapsed' })),
    group('Boosted tabs now', box)];
  },
  backup() {
    const file = h('input', { type: 'file', accept: 'application/json,.json', hidden: true, onchange: async () => {
      const f = file.files[0]; file.value = ''; if (!f) return;
      try {
        const j = JSON.parse(await f.text());
        if (j.app !== 'brave-category-home' || !Array.isArray(j.categories) || !Array.isArray(j.websites)) throw new Error('This is not a Brave Category Home backup.');
        dialog({ title: 'Restore backup?', body: h('p', {}, 'This replaces your current categories, websites, settings, widgets and to-dos. Wallpapers are not part of backups.'), actions: [{ label: 'Cancel' }, { label: 'Restore', kind: 'primary', onClick: async () => {
          const clean = sanitize(j);
          clean.settings.wallpaper.current = null;
          Object.assign(state, clean);
          for (const [id, url] of Object.entries(j.icons || {})) { try { await db.put({ id, kind: 'icon', blob: await dataURLToBlob(url), created: Date.now() }); } catch (_) {} }
          await chrome.storage.local.set({ todos: Array.isArray(j.todos) ? j.todos : [] });
          queueSave('settings', 'categories', 'websites', 'widgets'); await flush(); location.reload();
        } }] });
      } catch (e) { toast('Import failed: ' + e.message, { duration: 6000 }); }
    } });
    return [group('Export', note('Saves categories, websites, custom icons, settings, widgets and to-dos as a JSON file. Wallpapers are not included (they can be large).'),
      h('button', { class: 'btn primary', onclick: async () => {
        const icons = {}; for (const r of await db.all('icon')) icons[r.id] = await blobToDataURL(r.blob);
        const todos = (await chrome.storage.local.get('todos')).todos || [];
        const blob = new Blob([JSON.stringify({ app: 'brave-category-home', schema: 2, exported: new Date().toISOString(), settings: state.settings, categories: state.categories, websites: state.websites, widgets: state.widgets, todos, icons }, null, 1)], { type: 'application/json' });
        const a = h('a', { href: URL.createObjectURL(blob), download: 'brave-category-home-backup.json' }); document.body.append(a); a.click(); a.remove();
      } }, 'Export backup')),
    group('Restore', h('button', { class: 'btn', onclick: () => file.click() }, 'Import backup…'), file)];
  },
  advanced() {
    const usage = h('p', { class: 'muted small' }, 'Calculating storage…');
    navigator.storage && navigator.storage.estimate().then((e) => { usage.textContent = `Storage used by this extension: ${fmtBytes(e.usage || 0)} of ${fmtBytes(e.quota || 0)} available.`; });
    return [group('Storage', usage, h('button', { class: 'btn', onclick: async () => { const all = await chrome.storage.local.get(null); const ks = Object.keys(all).filter((k) => k.startsWith('cache:')); await chrome.storage.local.remove(ks); toast('Weather & news caches cleared'); } }, 'Clear weather/news caches')),
    group('Permissions', note('storage (settings), tabCapture + activeTab + offscreen (Volume Booster, only after you press Start on a tab). Optional per-site access is requested only for News feeds you allow.')),
    group('Reset', note('Removes only this extension’s own data (settings, categories, websites, widgets, to-dos, wallpapers, icons).'), h('button', { class: 'btn danger', onclick: () => dialog({ title: 'Restore defaults?', body: h('p', {}, 'All your customisation, websites, to-dos and uploaded wallpapers will be deleted. Consider exporting a backup first.'), actions: [{ label: 'Cancel' }, { label: 'Delete everything & restore', kind: 'danger', onClick: async () => { await resetEverything(); location.reload(); } }] }) }, 'Restore defaults…')),
    note('Brave Category Home 2.0.0 · theme: ' + themeName(state.settings.theme))];
  },
};

function show(id) {
  current = id;
  navBtns.forEach((b) => b.classList.toggle('active', b.dataset.id === id));
  content.replaceChildren(h('h3', {}, SECTIONS.find((s) => s[0] === id)[1]), ...[].concat(S[id]()));
  content.scrollTop = 0;
}

export function openSettings(section = current) {
  if (!panel) {
    navBtns = SECTIONS.map(([id, name]) => h('button', { class: 'nav-btn', dataset: { id }, onclick: () => show(id) }, name));
    content = h('div', { class: 'settings-content' });
    panel = h('aside', { id: 'settingsPanel', class: 'glass-strong', 'aria-label': 'Settings', role: 'dialog' },
      h('nav', { class: 'settings-nav' }, h('h2', {}, 'Settings'), ...navBtns), content,
      h('button', { class: 'icon-btn close', 'aria-label': 'Close settings', onclick: closeSettings }, '×'));
    document.body.append(panel);
    addEventListener('keydown', (e) => { if (e.key === 'Escape' && panel.classList.contains('open') && !document.querySelector('.overlay') && !document.body.classList.contains('idle')) closeSettings(); });
    document.addEventListener('idle:enter', closeSettings);
  }
  show(section);
  requestAnimationFrame(() => panel.classList.add('open'));
}
export function closeSettings() { if (panel) { panel.classList.remove('open'); if (isPreviewing()) endPreview(false); } }
