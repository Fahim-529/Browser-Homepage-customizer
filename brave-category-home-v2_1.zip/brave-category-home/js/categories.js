// Dashboard rendering of categories (glass cards) + category CRUD.
import { state, commitData, on } from './storage.js';
import { $, h, uid, dialog, toast, contextMenu } from './util.js';
import { makeTile, sitesIn, openSiteDialog, siteById, siteMenu, nudgeSite, nudgeSiteCategory, moveSite } from './websites.js';

let raf = 0;
export function scheduleRender() { cancelAnimationFrame(raf); raf = requestAnimationFrame(render); }

function render() {
  const root = $('#categories');
  const focusId = document.activeElement && document.activeElement.dataset && document.activeElement.classList.contains('site') ? document.activeElement.dataset.id : null;
  root.replaceChildren(...state.categories.map(card));
  if (focusId) root.querySelector(`.site[data-id="${CSS.escape(focusId)}"]`)?.focus();
}

function card(cat) {
  const sites = sitesIn(cat.id);
  const grid = h('div', { class: 'site-grid', dataset: { cat: cat.id } }, sites.length ? sites.map(makeTile) : h('div', { class: 'empty' }, 'Drop websites here or click + to add'));
  return h('section', { class: 'cat-card glass', dataset: { id: cat.id }, style: { '--cat': cat.color } },
    h('header', { class: 'cat-head', draggable: true, title: 'Drag to reorder categories' },
      h('span', { class: 'cat-chip' }, cat.icon), h('h2', {}, cat.name), h('span', { class: 'count muted' }, String(sites.length)),
      h('span', { class: 'spacer' }),
      h('button', { class: 'icon-btn small', title: 'Add website', 'aria-label': 'Add website to ' + cat.name, onclick: () => openSiteDialog(null, cat.id) }, '+'),
      h('button', { class: 'icon-btn small', title: 'Category options', 'aria-label': 'Options for ' + cat.name, onclick: (e) => { const r = e.currentTarget.getBoundingClientRect(); categoryMenu(r.left, r.bottom + 4, cat); } }, '⋯')),
    grid);
}

export function categoryMenu(x, y, cat) {
  contextMenu(x, y, [
    { label: 'Add website…', onClick: () => openSiteDialog(null, cat.id) },
    { label: 'Rename / change icon & color…', onClick: () => openCategoryDialog(cat) },
    { label: 'Move earlier', onClick: () => nudgeCategory(cat.id, -1) },
    { label: 'Move later', onClick: () => nudgeCategory(cat.id, 1) },
    { sep: true },
    { label: 'Delete…', danger: true, onClick: () => deleteCategoryFlow(cat) },
  ]);
}

export function moveCategory(id, refId, after) {
  const i = state.categories.findIndex((c) => c.id === id); if (i < 0) return;
  const [c] = state.categories.splice(i, 1);
  let at = refId ? state.categories.findIndex((x) => x.id === refId) : state.categories.length;
  if (at < 0) at = state.categories.length; else if (after) at++;
  state.categories.splice(at, 0, c);
  commitData(); // websites keep their categoryId, so nothing is lost
}
export function nudgeCategory(id, dir) {
  const i = state.categories.findIndex((c) => c.id === id), j = i + dir;
  if (i < 0 || j < 0 || j >= state.categories.length) return;
  moveCategory(id, state.categories[j].id, dir > 0);
}

const PALETTE = ['#8b7cff', '#ff6b8b', '#4cc9a6', '#5aa9ff', '#ffb454', '#7bd0ff', '#ff7ad9', '#9aa5b1', '#b5e36b', '#ff8a5b'];
export function openCategoryDialog(cat = null) {
  const name = h('input', { type: 'text', maxlength: '30', value: cat ? cat.name : '', placeholder: 'Category name' });
  const icon = h('input', { type: 'text', maxlength: '4', value: cat ? cat.icon : '★', placeholder: '★' });
  const color = h('input', { type: 'color', value: cat ? cat.color : PALETTE[state.categories.length % PALETTE.length] });
  const err = h('p', { class: 'form-error', role: 'alert' });
  dialog({
    title: cat ? 'Edit category' : 'New category',
    body: h('div', { class: 'form' }, h('label', {}, 'Name', name), h('label', {}, 'Icon (emoji or short text)', icon), h('label', {}, 'Color', color), err),
    actions: [{ label: 'Cancel' }, { label: cat ? 'Save' : 'Create', kind: 'primary', onClick: () => {
      const n = name.value.trim();
      if (!n) { err.textContent = 'Enter a category name.'; return false; }
      if (state.categories.some((c) => c.id !== (cat && cat.id) && c.name.toLowerCase() === n.toLowerCase())) { err.textContent = 'A category with that name already exists.'; return false; }
      const data = { name: n, icon: icon.value.trim() || '•', color: color.value };
      if (cat) Object.assign(cat, data); else state.categories.push({ id: uid('c'), ...data });
      commitData(); toast(cat ? 'Category saved' : 'Category created');
    } }],
  });
}

export function deleteCategoryFlow(cat) {
  if (state.categories.length <= 1) return toast('You need at least one category.');
  const n = sitesIn(cat.id).length;
  const others = state.categories.filter((c) => c.id !== cat.id);
  const target = h('select', {}, others.map((c) => h('option', { value: c.id }, c.name)));
  const mode = { v: 'move' };
  const body = n === 0 ? h('p', {}, `Delete the empty category “${cat.name}”?`) : h('div', { class: 'form' },
    h('p', {}, `“${cat.name}” contains ${n} website${n > 1 ? 's' : ''}. What should happen to them?`),
    h('label', { class: 'radio' }, h('input', { type: 'radio', name: 'dm', checked: true, onchange: () => { mode.v = 'move'; } }), ' Move them to ', target),
    h('label', { class: 'radio' }, h('input', { type: 'radio', name: 'dm', onchange: () => { mode.v = 'delete'; } }), ` Delete the category and its ${n} website${n > 1 ? 's' : ''}`));
  dialog({ title: 'Delete category', body, actions: [{ label: 'Cancel' }, { label: 'Delete category', kind: 'danger', onClick: () => {
    const removedSites = sitesIn(cat.id);
    if (mode.v === 'move' && n) removedSites.forEach((s) => { s.categoryId = target.value; }); else state.websites = state.websites.filter((s) => s.categoryId !== cat.id);
    const idx = state.categories.findIndex((c) => c.id === cat.id);
    const snapshot = { cat, idx, sites: mode.v === 'delete' ? removedSites : [], movedIds: mode.v === 'move' ? removedSites.map((s) => s.id) : [] };
    state.categories.splice(idx, 1); commitData();
    toast(`Deleted “${cat.name}”`, { duration: 7000, action: { label: 'Undo', onClick: () => {
      state.categories.splice(Math.min(snapshot.idx, state.categories.length), 0, snapshot.cat);
      snapshot.sites.forEach((s) => state.websites.push(s));
      snapshot.movedIds.forEach((id) => { const s = siteById(id); if (s) s.categoryId = snapshot.cat.id; });
      commitData();
    } } });
  } }] });
}

// Keyboard: Alt+Left/Right reorder inside a category, Alt+Up/Down moves between categories. Shift+F10 / right-click opens the menu.
export function initCategories() {
  render();
  on('data', scheduleRender);
  on('settings', (e) => { if (e.detail.path.startsWith('icons.fetchFavicons')) scheduleRender(); });
  const root = $('#categories');
  root.addEventListener('contextmenu', (e) => {
    const t = e.target.closest('.site');
    if (t) { e.preventDefault(); siteMenu(e.clientX, e.clientY, siteById(t.dataset.id)); return; }
    const head = e.target.closest('.cat-head');
    if (head) { e.preventDefault(); categoryMenu(e.clientX, e.clientY, state.categories.find((c) => c.id === head.parentElement.dataset.id)); }
  });
  root.addEventListener('keydown', (e) => {
    const t = e.target.closest('.site'); if (!t || !e.altKey) return;
    const map = { ArrowLeft: () => nudgeSite(t.dataset.id, -1), ArrowRight: () => nudgeSite(t.dataset.id, 1), ArrowUp: () => nudgeSiteCategory(t.dataset.id, -1), ArrowDown: () => nudgeSiteCategory(t.dataset.id, 1) };
    if (map[e.key]) { e.preventDefault(); map[e.key](); }
  });
}
