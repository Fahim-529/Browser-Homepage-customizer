// Optional, lazily loaded widgets. A widget's code is only fetched when it is added AND visible.
import { state, commitWidgets, on, WIDGET_LIMITS } from './storage.js';
import { $, h, uid } from './util.js';
import { parseWidgetFile } from './widget-file.js';

export const WIDGETS = {
  weather: { title: 'Weather', load: () => import('./weather.js') },
  todo: { title: 'To-do List', load: () => import('./todo.js') },
  news: { title: 'News', load: () => import('./news.js') },
};
// Built-in widgets are WIDGETS[type]; installed widget files use the type 'c:<id>' and run in a sandbox (custom-widget.js).
export const customList = () => state.widgets.custom;
export function defOf(type) {
  if (WIDGETS[type]) return WIDGETS[type];
  const c = state.widgets.custom.find((x) => 'c:' + x.id === type);
  if (!c) return { title: 'Missing widget', load: () => Promise.reject(new Error('This widget is no longer installed.')) };
  return { title: (c.icon ? c.icon + ' ' : '') + c.name, load: () => import('./custom-widget.js'), custom: c };
}
export function installWidgetText(text, filename) {
  const p = parseWidgetFile(text, filename);
  const list = state.widgets.custom, old = list.find((c) => c.name.toLowerCase() === p.name.toLowerCase());
  if (!old && list.length >= WIDGET_LIMITS.maxFiles) throw new Error('You can install up to ' + WIDGET_LIMITS.maxFiles + ' widget files. Uninstall one first.');
  const rec = old || { id: uid('w'), data: {}, v: 0 };
  Object.assign(rec, { name: p.name, icon: p.icon, size: p.size, height: p.height, html: p.html, v: (rec.v || 0) + 1 });
  if (!old) list.push(rec);
  const type = 'c:' + rec.id;
  if (!state.widgets.items.some((w) => w.type === type)) state.widgets.items.push({ type, visible: true, size: rec.size });
  else state.widgets.items.find((w) => w.type === type).visible = true;
  commitWidgets();
  return { rec, updated: !!old };
}
export function uninstallCustom(type) {
  state.widgets.items = state.widgets.items.filter((w) => w.type !== type);
  state.widgets.custom = state.widgets.custom.filter((c) => 'c:' + c.id !== type);
  commitWidgets();
}
export const SIZES = { s: 'Compact', m: 'Standard', l: 'Wide' };
const inst = new Map(); // type -> { el, body, size, ver, api }
let dragType = null;

export const addWidget = (type) => { if (!state.widgets.items.some((w) => w.type === type)) { state.widgets.items.push({ type, visible: true, size: 'm' }); commitWidgets(); } };
export const removeWidget = (type) => { state.widgets.items = state.widgets.items.filter((w) => w.type !== type); commitWidgets(); };
export const setVisible = (type, v) => { const w = state.widgets.items.find((x) => x.type === type); if (w) { w.visible = v; commitWidgets(); } };
export const setSize = (type, size) => { const w = state.widgets.items.find((x) => x.type === type); if (w) { w.size = size; commitWidgets(); } };
export function moveWidget(type, dir) {
  const a = state.widgets.items, i = a.findIndex((w) => w.type === type), j = i + dir;
  if (i < 0 || j < 0 || j >= a.length) return;
  [a[i], a[j]] = [a[j], a[i]]; commitWidgets();
}
function reorderTo(type, refType, after) {
  const a = state.widgets.items, i = a.findIndex((w) => w.type === type);
  if (i < 0) return;
  const [w] = a.splice(i, 1);
  let at = a.findIndex((x) => x.type === refType); if (at < 0) at = a.length; else if (after) at++;
  a.splice(at, 0, w); commitWidgets();
}

async function mountBody(type, rec, size) {
  rec.body.replaceChildren(h('p', { class: 'muted pad' }, 'Loading…'));
  try {
    const def = defOf(type), mod = await def.load();
    rec.body.replaceChildren();
    rec.api && rec.api.destroy && rec.api.destroy();
    rec.api = (await mod.mount(rec.body, { size, config: state.widgets[type], widget: def.custom })) || {};
  } catch (e) { // a failing widget never breaks the homepage
    console.error('widget failed', type, e);
    rec.body.replaceChildren(h('div', { class: 'pad' }, h('p', {}, 'This widget could not load.'), h('button', { class: 'btn small', onclick: () => mountBody(type, rec, size) }, 'Retry')));
  }
}

function create(type) {
  const body = h('div', { class: 'widget-body' });
  const el = h('section', { class: 'widget glass', dataset: { type }, draggable: false },
    h('header', { class: 'widget-head', draggable: true, title: 'Drag to reorder' },
      h('h3', {}, defOf(type).title), h('span', { class: 'spacer' }),
      h('button', { class: 'icon-btn small', title: 'Hide widget (re-enable in Settings → Widgets)', 'aria-label': 'Hide ' + defOf(type).title, onclick: () => setVisible(type, false) }, '–')),
    body);
  const rec = { el, body, size: null, ver: null, api: null };
  const head = el.querySelector('.widget-head');
  head.addEventListener('dragstart', (e) => { dragType = type; e.dataTransfer.setData('text/plain', type); e.dataTransfer.effectAllowed = 'move'; el.classList.add('dragging'); });
  head.addEventListener('dragend', () => { dragType = null; el.classList.remove('dragging'); document.querySelectorAll('.widget').forEach((w) => w.classList.remove('drop-before', 'drop-after')); });
  return rec;
}

export function syncWidgets() {
  const area = $('#widgets'), want = state.widgets.items.filter((w) => w.visible);
  for (const [type, rec] of [...inst]) if (!want.some((w) => w.type === type)) { rec.api && rec.api.destroy && rec.api.destroy(); rec.el.remove(); inst.delete(type); }
  for (const w of want) {
    let rec = inst.get(w.type);
    if (!rec) { rec = create(w.type); inst.set(w.type, rec); }
    rec.el.dataset.size = w.size;
    area.append(rec.el); // re-appending in order keeps DOM order == configured order
    const def = defOf(w.type), ver = def.custom ? def.custom.v : 0;
    rec.el.querySelector('h3').textContent = def.title;
    if (rec.size !== w.size || rec.ver !== ver) { rec.size = w.size; rec.ver = ver; mountBody(w.type, rec, w.size); } // a re-installed widget file reloads itself
  }
  $('#sec-widgets').dataset.empty = want.length ? '0' : '1';
}

export function initWidgets() {
  syncWidgets();
  on('widgets', syncWidgets);
  const area = $('#widgets');
  area.addEventListener('dragover', (e) => {
    if (!dragType) return;
    const t = e.target.closest('.widget'); if (!t || t.dataset.type === dragType) return;
    e.preventDefault();
    const r = t.getBoundingClientRect(), after = e.clientX > r.left + r.width / 2;
    area.querySelectorAll('.widget').forEach((w) => w.classList.remove('drop-before', 'drop-after'));
    t.classList.add(after ? 'drop-after' : 'drop-before');
  });
  area.addEventListener('drop', (e) => {
    if (!dragType) return;
    const t = e.target.closest('.widget'); if (!t) return;
    e.preventDefault();
    const r = t.getBoundingClientRect(); reorderTo(dragType, t.dataset.type, e.clientX > r.left + r.width / 2);
  });
}
