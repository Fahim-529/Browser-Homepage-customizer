// Idle Mode: hides the extension UI so only the wallpaper remains. It does NOT hide Brave's toolbar/tabs;
// optional true fullscreen uses the Fullscreen API and therefore only starts from a user gesture.
import { state, on } from './storage.js';
import { $, toast } from './util.js';

let active = false, enteredFs = false, armedAt = 0, hideT = null, exitT = null;
export const isIdle = () => active;

export function parseCombo(str) {
  const parts = String(str || '').split('+');
  const code = parts.pop();
  return { code, alt: parts.includes('Alt'), ctrl: parts.includes('Ctrl'), shift: parts.includes('Shift'), meta: parts.includes('Meta') };
}
export const prettyCombo = (str) => String(str || '').replace(/Key|Digit/g, '').replace(/\+/g, ' + ');
export function comboFromEvent(e) {
  if (['Control', 'Shift', 'Alt', 'Meta'].includes(e.key)) return null;
  const mods = [e.ctrlKey && 'Ctrl', e.altKey && 'Alt', e.shiftKey && 'Shift', e.metaKey && 'Meta'].filter(Boolean);
  if (!mods.length && !/^F\d+$/.test(e.code)) return null; // require a modifier so typing is never hijacked
  return [...mods, e.code].join('+');
}
const matches = (e, c) => e.code === c.code && e.altKey === c.alt && e.ctrlKey === c.ctrl && e.shiftKey === c.shift && e.metaKey === c.meta;

function wake() {
  if (!active) return;
  document.body.classList.remove('idle-nocursor');
  $('#idleExit').classList.add('show');
  clearTimeout(hideT); clearTimeout(exitT);
  if (state.settings.idle.hideCursor) hideT = setTimeout(() => document.body.classList.add('idle-nocursor'), 2200);
  exitT = setTimeout(() => $('#idleExit').classList.remove('show'), 2600);
}

export function enter() {
  if (active) return;
  const s = state.settings.idle;
  active = true; armedAt = performance.now();
  document.dispatchEvent(new CustomEvent('idle:enter'));
  document.body.dataset.idleTransition = s.transition;
  document.body.classList.add('idle');
  document.activeElement && document.activeElement.blur && document.activeElement.blur();
  if (s.fullscreen && document.fullscreenEnabled) {
    document.documentElement.requestFullscreen().then(() => { enteredFs = true; }).catch(() => toast('Fullscreen was blocked by the browser.'));
  }
  wake();
}
export function exit() {
  if (!active) return;
  active = false;
  clearTimeout(hideT); clearTimeout(exitT);
  document.body.classList.remove('idle', 'idle-nocursor');
  $('#idleExit').classList.remove('show');
  if (enteredFs && document.fullscreenElement) document.exitFullscreen().catch(() => {});
  enteredFs = false;
  document.dispatchEvent(new CustomEvent('idle:exit'));
}
export const toggle = () => (active ? exit() : enter());

export function initIdle() {
  $('#idleBtn').addEventListener('click', enter);
  $('#idleExit').addEventListener('click', (e) => { e.stopPropagation(); exit(); });
  addEventListener('mousemove', wake, { passive: true });
  addEventListener('keydown', (e) => {
    const s = state.settings.idle;
    if (active && e.key === 'Escape' && s.escExit) { e.preventDefault(); exit(); return; }
    if (e.repeat || /^(INPUT|TEXTAREA|SELECT)$/.test(e.target.tagName) || e.target.isContentEditable) return;
    if (document.querySelector('.overlay')) return;
    if (matches(e, parseCombo(s.shortcut))) { e.preventDefault(); toggle(); }
  });
  addEventListener('click', (e) => {
    if (active && state.settings.idle.clickExit && performance.now() - armedAt > 350 && !e.target.closest('#idleExit')) exit();
  });
  // Leaving browser fullscreen (e.g. via Esc, which the browser consumes) also leaves Idle Mode.
  document.addEventListener('fullscreenchange', () => { if (enteredFs && !document.fullscreenElement) { enteredFs = false; exit(); } });
  on('settings', (e) => { if (e.detail.path === 'idle.transition') document.body.dataset.idleTransition = state.settings.idle.transition; });
}
