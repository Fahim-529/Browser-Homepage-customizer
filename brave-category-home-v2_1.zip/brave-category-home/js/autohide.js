// Auto-hide: after N seconds without any activity the website categories (optionally widgets too) fade out.
// Any mouse movement, click, key press, scroll or touch brings them back. The layout keeps its space, so nothing jumps.
import { state, on } from './storage.js';

let timer = null, lastX = -1, lastY = -1;
const cfg = () => state.settings.autohide;
const busy = () => document.hidden || document.body.classList.contains('idle') || document.querySelector('.overlay, .ctx, .dragging, #settingsPanel.open');

function show() { document.body.classList.remove('autohidden'); arm(); }
function arm(delay) {
  clearTimeout(timer);
  const c = cfg();
  if (!c.enabled) { document.body.classList.remove('autohidden'); return; }
  timer = setTimeout(() => {
    if (busy()) return arm(5000);            // never hide while a dialog, menu, drag or the settings panel is open
    document.body.classList.add('autohidden');
  }, delay != null ? delay : c.seconds * 1000);
}
function apply() { document.body.classList.toggle('autohide-widgets', !!cfg().widgets); show(); }

export function initAutohide() {
  apply();
  const wake = () => { if (document.body.classList.contains('autohidden') || true) show(); };
  addEventListener('mousemove', (e) => { // ignore tiny jitters (a resting mouse can still send events)
    if (Math.abs(e.clientX - lastX) + Math.abs(e.clientY - lastY) < 4) return;
    lastX = e.clientX; lastY = e.clientY; wake();
  }, { passive: true });
  for (const ev of ['pointerdown', 'keydown', 'wheel', 'touchstart', 'scroll']) addEventListener(ev, wake, { passive: true, capture: true });
  document.addEventListener('visibilitychange', () => { if (!document.hidden) show(); });
  document.addEventListener('idle:exit', show);
  on('settings', (e) => { if (e.detail.path.startsWith('autohide')) apply(); });
}
