// Small DOM + UI helpers shared by all modules. No innerHTML anywhere: text is always inserted as text nodes.
export const $ = (s, r = document) => r.querySelector(s);
export const $$ = (s, r = document) => [...r.querySelectorAll(s)];

export function h(tag, props, ...kids) {
  const e = document.createElement(tag);
  for (const [k, v] of Object.entries(props || {})) {
    if (v == null || v === false) continue;
    if (k === 'class') e.className = v;
    else if (k === 'style' && typeof v === 'object') Object.assign(e.style, v);
    else if (k === 'dataset' && typeof v === 'object') Object.assign(e.dataset, v);
    else if (k.startsWith('on') && typeof v === 'function') e.addEventListener(k.slice(2).toLowerCase(), v);
    else if (['value', 'checked', 'disabled', 'hidden', 'draggable', 'textContent', 'selected'].includes(k)) e[k] = v;
    else e.setAttribute(k, v === true ? '' : v);
  }
  const add = (k) => { if (k == null || k === false) return; if (Array.isArray(k)) k.forEach(add); else e.append(k instanceof Node ? k : document.createTextNode(String(k))); };
  kids.forEach(add);
  return e;
}

export const uid = (p = 'id') => p + '-' + (crypto.randomUUID ? crypto.randomUUID().slice(0, 8) : Math.random().toString(36).slice(2, 10));
export const clamp = (n, a, b) => Math.min(b, Math.max(a, n));
export const debounce = (fn, ms = 200) => { let t; const d = (...a) => { clearTimeout(t); t = setTimeout(() => fn(...a), ms); }; d.flush = () => { clearTimeout(t); }; return d; };

export function toast(msg, opts = {}) {
  const host = $('#toasts');
  if (!host) return;
  const el = h('div', { class: 'toast glass-strong', role: 'status' }, h('span', {}, msg));
  if (opts.action) el.append(h('button', { class: 'btn small', onclick: () => { opts.action.onClick(); el.remove(); } }, opts.action.label));
  host.append(el);
  requestAnimationFrame(() => el.classList.add('show'));
  setTimeout(() => { el.classList.remove('show'); setTimeout(() => el.remove(), 300); }, opts.duration || 3200);
}

// Generic modal dialog. body: Node. actions: [{label, kind:'primary'|'danger'|'', onClick(close) -> may return false to keep open}]
export function dialog({ title, body, actions = [], wide = false, onClose }) {
  const prevFocus = document.activeElement;
  const close = () => { overlay.remove(); document.removeEventListener('keydown', onKey, true); onClose && onClose(); prevFocus && prevFocus.focus && prevFocus.focus(); };
  const onKey = (e) => { if (e.key === 'Escape') { e.stopPropagation(); close(); } };
  const card = h('div', { class: 'dialog glass-strong' + (wide ? ' wide' : ''), role: 'dialog', 'aria-modal': 'true', 'aria-label': title },
    h('h2', {}, title), body,
    h('div', { class: 'dialog-actions' }, actions.map((a) => h('button', { class: 'btn ' + (a.kind || ''), onclick: async () => { if ((await a.onClick(close)) !== false) close(); } }, a.label)))
  );
  const overlay = h('div', { class: 'overlay', onmousedown: (e) => { if (e.target === overlay) close(); } }, card);
  $('#modals').append(overlay);
  document.addEventListener('keydown', onKey, true);
  (card.querySelector('input,select,button') || card).focus();
  return { close, card };
}

export function contextMenu(x, y, items) {
  $$('.ctx').forEach((m) => m.remove());
  const menu = h('div', { class: 'ctx glass-strong', role: 'menu' }, items.filter(Boolean).map((it) =>
    it.sep ? h('hr') : h('button', { role: 'menuitem', class: it.danger ? 'danger' : '', onclick: () => { menu.remove(); it.onClick(); } }, it.label)));
  document.body.append(menu);
  const r = menu.getBoundingClientRect();
  menu.style.left = Math.min(x, innerWidth - r.width - 8) + 'px';
  menu.style.top = Math.min(y, innerHeight - r.height - 8) + 'px';
  const off = (e) => { if (e.type === 'keydown' && e.key !== 'Escape') return; menu.remove(); removeEventListener('mousedown', off, true); removeEventListener('keydown', off, true); removeEventListener('blur', off); };
  setTimeout(() => { addEventListener('mousedown', (e) => { if (!menu.contains(e.target)) off(e); }, true); addEventListener('keydown', off, true); addEventListener('blur', off); });
  menu.querySelector('button')?.focus();
}

export function normalizeUrl(raw) {
  let u = String(raw || '').trim();
  if (!u) return null;
  if (!/^[a-z][a-z0-9+.-]*:\/\//i.test(u)) u = 'https://' + u;
  try {
    const url = new URL(u);
    if (!['http:', 'https:'].includes(url.protocol)) return null;
    if (!url.hostname.includes('.') && url.hostname !== 'localhost') return null;
    return url.href;
  } catch { return null; }
}

// Decode any image the browser can display, downscale to a square PNG (keeps stored icons tiny).
export function fileToIconBlob(file, size = 256) {
  return new Promise((resolve, reject) => {
    if (!file || !/^image\//.test(file.type)) return reject(new Error('Please choose an image file.'));
    if (file.size > 5 * 1024 * 1024) return reject(new Error('Image is larger than 5 MB.'));
    const url = URL.createObjectURL(file);
    const img = new Image();
    img.onload = () => {
      const c = document.createElement('canvas'); c.width = c.height = size;
      const s = Math.min(size / (img.naturalWidth || size), size / (img.naturalHeight || size));
      const w = (img.naturalWidth || size) * s, hh = (img.naturalHeight || size) * s;
      c.getContext('2d').drawImage(img, (size - w) / 2, (size - hh) / 2, w, hh);
      URL.revokeObjectURL(url);
      c.toBlob((b) => b ? resolve(b) : reject(new Error('Could not process the image.')), 'image/png');
    };
    img.onerror = () => { URL.revokeObjectURL(url); reject(new Error('That file is not a valid image.')); };
    img.src = url;
  });
}

export const blobToDataURL = (b) => new Promise((res, rej) => { const r = new FileReader(); r.onload = () => res(r.result); r.onerror = rej; r.readAsDataURL(b); });
export const dataURLToBlob = async (u) => (await fetch(u)).blob();
export const fmtBytes = (n) => n > 1e9 ? (n / 1e9).toFixed(1) + ' GB' : n > 1e6 ? (n / 1e6).toFixed(1) + ' MB' : Math.round(n / 1e3) + ' KB';
