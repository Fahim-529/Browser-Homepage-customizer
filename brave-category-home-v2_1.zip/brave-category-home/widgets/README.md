# Widget files

A widget is ONE `.html` file. Install it in **Settings → Widgets → Choose widget file…** (or the **+ Widget** button).
Installing a file with the same name updates the old one.

Included: `timer.widget.html` (ready to install) and `template.widget.html` (copy it to start your own).

## Format
```html
<!doctype html>
<html><head>
<meta charset="utf-8">
<title>My Widget</title>
<meta name="widget-format" content="1">      <!-- REQUIRED -->
<meta name="widget-name" content="My Widget"> <!-- optional (default: <title>) -->
<meta name="widget-icon" content="★">         <!-- optional, 1-4 characters -->
<meta name="widget-size" content="m">         <!-- s | m | l -->
<meta name="widget-height" content="auto">    <!-- "auto" or 60-600 (px) -->
</head><body> ...your HTML, CSS and JavaScript... </body></html>
```

## What your code can use
* `widget.storage.get(key, default)`, `.set(key, text)`, `.remove(key)` – saved on this device, text only, 20 KB per widget.
* `widget.resize(px)` – change height (not needed with `auto`).
* CSS variables from the dashboard theme: `var(--text)`, `var(--accent)`, `var(--bg)`.
* Inline `<script>` / `<style>`, Web Audio, timers, canvas, `data:` images.

## Safety (why you can install files from anyone without risking your dashboard)
Widgets run inside a sandboxed iframe: no access to your tabs, websites, settings, other widgets or any
Chrome extension API, and **no network access at all** (blocked by the extension's content-security policy).
Still, install only files you trust. Max file size 200 KB, max 12 installed widgets.

## Ask an AI to make one
"Make a Category Home widget file for <idea> using the format in template.widget.html. One .html file, no external libraries or internet."
