const $ = (s) => document.querySelector(s);
let tab = null, active = false, muted = false;
const UNSUPPORTED = /^(chrome|brave|edge|about|chrome-extension|chrome-search|view-source|devtools):/i;

function showMsg(t) { $('#msg').textContent = t; $('#msg').hidden = !t; }
const send = (m) => chrome.runtime.sendMessage(m);
function paint() {
  $('#pct').textContent = $('#slider').value + '%';
  $('#toggle').textContent = active ? 'Stop' : 'Start';
  $('#toggle').classList.toggle('stop', active);
  $('#mute').textContent = muted ? '🔇' : '🔊';
}

async function init() {
  [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab) { showMsg('No active tab found.'); $('#controls').hidden = true; return; }
  $('#tabTitle').textContent = tab.title || tab.url || '';
  if (!tab.url || UNSUPPORTED.test(tab.url) || /chromewebstore\.google\.com|chrome\.google\.com\/webstore/.test(tab.url)) {
    showMsg('Browser pages (brave://, the New Tab page, the web store) cannot be captured. Open a regular website tab and click the icon there.');
    $('#controls').hidden = true; return;
  }
  const r = await send({ type: 'vb:list' }).catch(() => null);
  const mine = r && r.ok && r.list.find((x) => x.tabId === tab.id);
  if (mine) { active = true; muted = mine.muted; $('#slider').value = mine.percent; }
  paint();
}

let t;
$('#slider').addEventListener('input', () => {
  paint();
  if (!active) return;
  clearTimeout(t);
  t = setTimeout(() => send({ type: 'vb:set', tabId: tab.id, percent: +$('#slider').value, muted: false }).then(() => { muted = false; paint(); }), 30);
});
$('#reset').onclick = async () => {
  $('#slider').value = 100; muted = false;
  if (active) await send({ type: 'vb:set', tabId: tab.id, percent: 100, muted: false });
  paint();
};
$('#mute').onclick = async () => {
  if (!active) { showMsg('Press Start first, then you can mute or boost.'); return; }
  const r = await send({ type: 'vb:set', tabId: tab.id, muted: !muted });
  if (r && r.ok) { muted = !muted; paint(); } else showMsg((r && r.error) || 'Failed.');
};
$('#toggle').onclick = async () => {
  showMsg('');
  try {
    if (active) {
      const r = await send({ type: 'vb:stop', tabId: tab.id });
      if (r && r.ok) { active = false; muted = false; } else showMsg((r && r.error) || 'Could not stop.');
    } else {
      // Needs the activeTab grant that the toolbar click gave us, and must happen right now.
      const streamId = await chrome.tabCapture.getMediaStreamId({ targetTabId: tab.id });
      const r = await send({ type: 'vb:start', tabId: tab.id, streamId, percent: +$('#slider').value, title: tab.title });
      if (r && r.ok) active = true; else showMsg((r && r.error) || 'Could not start capture.');
    }
  } catch (e) { showMsg('Capture failed: ' + ((e && e.message) || e)); }
  paint();
};
init().catch((e) => showMsg(String(e)));
