// Offscreen document: receives a tab-capture stream and plays it back through a GainNode.
// Capturing a tab mutes its normal output, so playing the processed stream here does not duplicate audio.
// Stopping the capture (stopping tracks) restores the tab's own audio routing.
const caps = new Map(); // tabId -> { stream, ctx, gain, comp, percent, muted, title, limited }

function apply(c) {
  c.gain.gain.setTargetAtTime(c.muted ? 0 : c.percent / 100, c.ctx.currentTime, 0.015);
  const limit = c.percent > 100 && !c.muted; // only engage the limiter when amplifying
  if (limit !== c.limited) {
    c.gain.disconnect();
    c.gain.connect(limit ? c.comp : c.ctx.destination);
    c.limited = limit;
  }
}
const notify = (tabId, extra) => setTimeout(() => {
  const c = caps.get(tabId);
  chrome.runtime.sendMessage({ type: 'vb:changed', tabId, percent: c && c.percent, muted: c && c.muted, empty: caps.size === 0, ...extra }).catch(() => {});
}, 30);

function stopCap(tabId, ended) {
  const c = caps.get(tabId);
  if (!c) return false;
  caps.delete(tabId);
  c.stream.getTracks().forEach((t) => t.stop());
  c.ctx.close().catch(() => {});
  notify(tabId, { ended: true });
  return true;
}

async function start({ tabId, streamId, percent, title }) {
  if (caps.has(tabId)) { const c = caps.get(tabId); c.percent = percent; c.muted = false; apply(c); notify(tabId); return; }
  // Tab audio only: no microphone is requested.
  const stream = await navigator.mediaDevices.getUserMedia({
    audio: { mandatory: { chromeMediaSource: 'tab', chromeMediaSourceId: streamId } },
    video: false
  });
  const ctx = new AudioContext();
  if (ctx.state === 'suspended') await ctx.resume();
  const src = ctx.createMediaStreamSource(stream);
  const gain = ctx.createGain();
  const comp = ctx.createDynamicsCompressor(); // soft limiter to reduce clipping above 100%
  comp.threshold.value = -6; comp.knee.value = 6; comp.ratio.value = 12; comp.attack.value = 0.003; comp.release.value = 0.2;
  comp.connect(ctx.destination);
  src.connect(gain);
  gain.connect(ctx.destination);
  const c = { stream, ctx, gain, comp, percent, muted: false, title: title || '', limited: false };
  caps.set(tabId, c);
  apply(c);
  stream.getAudioTracks()[0]?.addEventListener('ended', () => stopCap(tabId, true));
  notify(tabId);
}

chrome.runtime.onMessage.addListener((m, _s, send) => {
  if (m.target !== 'offscreen') return;
  (async () => {
    try {
      if (m.type === 'start') { await start(m); send({ ok: true }); }
      else if (m.type === 'set') {
        const c = caps.get(m.tabId);
        if (!c) return send({ ok: false, error: 'This tab is not being boosted.' });
        if (typeof m.percent === 'number') c.percent = Math.max(0, Math.min(200, Math.round(m.percent)));
        if (typeof m.muted === 'boolean') c.muted = m.muted;
        apply(c); notify(m.tabId); send({ ok: true });
      } else if (m.type === 'stop') send({ ok: stopCap(m.tabId) });
      else if (m.type === 'list') send({ ok: true, list: [...caps].map(([tabId, c]) => ({ tabId, title: c.title, percent: c.percent, muted: c.muted })) });
    } catch (e) { send({ ok: false, error: String((e && e.message) || e) }); }
  })();
  return true;
});
