// Runs inside a SANDBOXED page (see "sandbox" in manifest.json): unique origin, no chrome.* APIs, no network (CSP connect-src 'none').
// It receives the widget's HTML from the dashboard and renders it. The widget can only talk back through the tiny `widget` bridge below.
const PARENT = window.parent;
let booted = false;

// This function is serialised into the widget document, so it must not reference anything outside itself.
function bridge(init) {
  var P = parent, data = init.data || {}, root = document.documentElement;
  function theme(t) { for (var k in t) if (/^[a-z-]+$/.test(k)) root.style.setProperty('--' + k, String(t[k])); }
  theme(init.theme || {});
  window.widget = {
    size: init.size,
    storage: {
      get: function (k, d) { k = String(k); return Object.prototype.hasOwnProperty.call(data, k) ? data[k] : (d === undefined ? null : d); },
      set: function (k, v) { k = String(k); v = String(v); data[k] = v; P.postMessage({ type: 'storage:set', key: k, value: v }, '*'); },
      remove: function (k) { k = String(k); delete data[k]; P.postMessage({ type: 'storage:remove', key: k }, '*'); }
    },
    resize: function (px) { P.postMessage({ type: 'resize', height: Number(px) }, '*'); }
  };
  addEventListener('message', function (e) {
    if (e.source !== P || !e.data) return;
    if (e.data.type === 'theme') theme(e.data.theme || {});
  });
  if (init.auto) {
    var send = function () { P.postMessage({ type: 'resize', height: Math.ceil(root.scrollHeight) }, '*'); };
    addEventListener('load', function () { send(); if (window.ResizeObserver) new ResizeObserver(send).observe(document.body); });
  }
}

const BASE_CSS = 'html,body{margin:0;padding:0;background:transparent;color:var(--text,#fff);font:14px/1.4 system-ui,-apple-system,"Segoe UI",Roboto,sans-serif}' +
  'button,input,select{font:inherit;color:inherit}button{cursor:pointer;border:1px solid rgba(255,255,255,.22);background:rgba(255,255,255,.12);border-radius:10px;padding:6px 12px}button:hover{background:rgba(255,255,255,.22)}' +
  'input,select{background:rgba(255,255,255,.1);border:1px solid rgba(255,255,255,.22);border-radius:10px;padding:6px 8px}';

const esc = (o) => JSON.stringify(o).replace(/</g, '\\u003c').replace(/\u2028/g, '\\u2028').replace(/\u2029/g, '\\u2029');

addEventListener('message', (e) => {
  if (e.source !== PARENT || booted || !e.data || e.data.type !== 'init' || typeof e.data.html !== 'string') return;
  booted = true;
  const m = e.data;
  const inject = '<style>' + BASE_CSS + '</style><script>(' + bridge.toString() + ')(' + esc({ data: m.data, theme: m.theme, size: m.size, auto: !!m.auto }) + ');<\/script>';
  let html = m.html;
  if (/<head[^>]*>/i.test(html)) html = html.replace(/<head[^>]*>/i, (t) => t + inject);
  else if (/<html[^>]*>/i.test(html)) html = html.replace(/<html[^>]*>/i, (t) => t + '<head>' + inject + '</head>');
  else html = '<!doctype html><html><head>' + inject + '</head><body>' + html + '</body></html>';
  document.open(); document.write(html); document.close();
});
PARENT.postMessage({ type: 'ready' }, '*');
