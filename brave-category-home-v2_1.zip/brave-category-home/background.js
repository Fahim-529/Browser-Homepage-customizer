// Service worker: owns the offscreen document used by the Volume Booster and relays messages.
const OFFSCREEN = 'offscreen.html';

async function hasOffscreen() {
  const ctx = await chrome.runtime.getContexts({ contextTypes: ['OFFSCREEN_DOCUMENT'] });
  return ctx.length > 0;
}
async function ensureOffscreen() {
  if (await hasOffscreen()) return;
  await chrome.offscreen.createDocument({
    url: OFFSCREEN,
    reasons: ['USER_MEDIA'],
    justification: 'Route captured tab audio through a Web Audio gain node (Volume Booster).'
  });
}
const toOffscreen = (msg) => chrome.runtime.sendMessage({ target: 'offscreen', ...msg });

function setBadge(tabId, percent, muted) {
  if (tabId == null) return;
  chrome.action.setBadgeText({ tabId, text: muted ? 'M' : String(percent) }).catch(() => {});
  chrome.action.setBadgeBackgroundColor({ tabId, color: percent > 100 ? '#d9822b' : '#3a7bd5' }).catch(() => {});
}
const clearBadge = (tabId) => chrome.action.setBadgeText({ tabId, text: '' }).catch(() => {});

chrome.runtime.onMessage.addListener((m, _sender, send) => {
  if (m.target) return; // addressed to another context

  if (m.type === 'vb:changed') { // broadcast from the offscreen document
    if (m.ended) clearBadge(m.tabId); else setBadge(m.tabId, m.percent, m.muted);
    if (m.empty) chrome.offscreen.closeDocument().catch(() => {});
    return;
  }

  (async () => {
    try {
      if (m.type === 'vb:start') {
        await ensureOffscreen();
        const r = await toOffscreen({ type: 'start', tabId: m.tabId, streamId: m.streamId, percent: m.percent, title: m.title });
        if (r && r.ok) setBadge(m.tabId, m.percent, false);
        send(r || { ok: false, error: 'The audio engine did not respond.' });
      } else if (m.type === 'vb:set' || m.type === 'vb:stop') {
        if (!(await hasOffscreen())) return send({ ok: false, error: 'Nothing is being boosted.' });
        send(await toOffscreen({ type: m.type === 'vb:set' ? 'set' : 'stop', tabId: m.tabId, percent: m.percent, muted: m.muted }));
      } else if (m.type === 'vb:list') {
        if (!(await hasOffscreen())) return send({ ok: true, list: [] });
        send(await toOffscreen({ type: 'list' }));
      } else send({ ok: false, error: 'Unknown message' });
    } catch (e) { send({ ok: false, error: String((e && e.message) || e) }); }
  })();
  return true;
});

// A closed tab ends its capture stream; make sure our side is cleaned up too.
chrome.tabs.onRemoved.addListener(async (tabId) => {
  try { if (await hasOffscreen()) await toOffscreen({ type: 'stop', tabId }); } catch (_) {}
});
