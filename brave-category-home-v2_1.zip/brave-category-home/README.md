# Brave Category Home 2.1

Minimalist, iOS-inspired "Liquid Glass" new-tab dashboard for Brave / Chromium (Manifest V3). Upgrades the 1.0 sidebar extension in place: your categories, websites, icon size, label setting and wallpaper are migrated automatically (a copy of the old category data is kept under `legacyBackup`).

## Install
1. Unzip. Open `brave://extensions`, enable **Developer mode**.
2. **Load unpacked** → choose the `brave-category-home` folder (the one containing `manifest.json`).
3. Open a new tab. Pin the extension's toolbar icon if you want quick access to the Volume Booster.

## What's inside
| Area | Notes |
|---|---|
| Dashboard Grid | Clock, Google search, optional widgets, category cards, Volume Booster. Section order/visibility in Settings → Layout |
| Icons | iOS-style tiles; size, shape, radius, spacing, background (transparent/solid/glass), shadow, names; favicon or uploaded icon (stored locally, downscaled to 256 px) |
| Liquid Glass | Opacity, blur, border, radius, shadow, brightness; 5 presets + Custom Theme; fallback background when `backdrop-filter` is unsupported |
| Wallpapers | MP4/WebM video or PNG/JPEG/WebP/GIF/AVIF, kept in IndexedDB; preview/keep, brightness, blur, overlay, opacity, speed, pause, slideshow; pauses when the tab is hidden; honors reduced motion |
| Idle Mode | Hides all UI; Esc, click, configurable shortcut (default Alt+I), on-screen exit button on mouse move; optional browser fullscreen |
| Search | Google only (`https://www.google.com/search?q=…`, encoded; empty = no-op) |
| Clock | Digital / analog / flip, 12/24 h, seconds, date, greeting, font, size, colour, alignment |
| Management | Add/edit/delete(with Undo)/duplicate/move websites, URL validation, duplicate prevention; create/rename/recolour/reorder/delete categories (choose move vs delete sites); drag & drop for sites and categories; keyboard: Alt+←/→ reorder, Alt+↑/↓ change category, Shift+F10 menu |
| Widgets | Weather (Open-Meteo, no key), To-do (local), News (BBC/The Verge RSS or your own feed); add/remove/hide/resize/reorder; code lazy-loaded |
| Backup | Export/import JSON (settings, sites, icons, widgets, to-dos; wallpapers excluded) |

## New in 2.1
* **Installable widgets** – add any widget as a single `.html` file (Settings → Widgets, or **+ Widget**). A ready-made **Timer** is in `widgets/timer.widget.html`; format and template in `widgets/README.md`. Widget files run in a sandbox with no network access.
* **Auto-hide categories** – categories fade out after N seconds of no use (Settings → Layout; default 30 s, optional "also hide widgets"). Any mouse move, click, key or scroll brings them back; nothing hides while a dialog, menu, drag or Settings is open.
* **Gmail button** – small fixed button (bottom right or left) that opens Gmail; stays visible when categories are hidden.
* **Security hardening** – all Weather/News traffic goes through `js/net.js`: https only, no credentials, no local/IP addresses, redirects to other sites blocked, 10 s timeout, size limits, flood guard; weather JSON is rebuilt from validated numbers only; feeds with DOCTYPE/ENTITY (XML bombs) are rejected; headlines are cleaned of hidden/bidi characters; only https links and images are kept; caches and restored backups are re-validated. The manifest now has a strict Content-Security-Policy (no inline/eval scripts, no plugins, https-only connections and images).
* Fixed: an internal helper ignored `data-*` attributes, which could break drag-to-reorder of widgets/categories.

## Volume Booster – how it really works
Chromium only lets an extension capture a tab's audio after the user invokes the extension **on that tab**. Therefore:
* Open the tab you want to boost → click the toolbar icon → **Start** → choose 0–200 %.
* The audio is routed through `chrome.tabCapture` → offscreen document → Web Audio `GainNode` (gain = percent / 100). A soft limiter engages above 100 % to reduce clipping.
* Capturing mutes the tab's own output and plays the processed stream instead, so audio is not duplicated; **Stop** (or closing the tab) restores normal audio. No microphone is ever requested.
* The homepage panel lists tabs that are *currently* boosted and lets you adjust, mute, reset or stop them. It cannot *start* a boost (browser rule), cannot boost all tabs at once, cannot capture `brave://` pages, and DRM-protected video (Netflix etc.) may be silent.
* High gain can distort audio and damage hearing.

## Permissions (and why)
* `storage` – settings, sites, to-dos, caches.
* `tabCapture`, `activeTab`, `offscreen` – Volume Booster only; nothing is captured until you press Start.
* Optional `https://*/*` host access – declared optional so the News widget can ask **per feed origin** (e.g. feeds.bbci.co.uk) at the moment you click "Allow access". Never granted at install.
* No `tabs`, `history`, `cookies`, microphone or location permission. Weather location uses the browser's geolocation prompt only if you press "Use my location".

## External services (disclosure)
* Favicons: Google's favicon service (`google.com/s2/favicons`) receives each site's domain. Disable in Settings → Icons (letter icons / uploaded icons then).
* Weather: open-meteo.com receives the coordinates of your chosen place.
* News: only the feed host you allow. No API keys are used anywhere.

## Known limitations
* Not every browser decodes every video codec; unsupported files are rejected with a message.
* Mic button omitted on purpose (Brave has no Google speech backend).
* Drag & drop uses HTML5 drag events: mouse/trackpad only (keyboard alternatives provided).
* Idle Mode cannot hide Brave's toolbar/tabs unless browser fullscreen is enabled (user-gesture required).
* The News "Feed…" option uses a basic browser prompt dialog.
* The Brave "New Tab" override can be reverted by the user's browser settings if they pick another page.

## Testing report
Automated (Node + jsdom + fake-indexeddb; 2.0: 63 checks, 2.1 adds over 80 more for widgets, auto-hide, sanitising, network guard and the sandbox bridge, all passing): v1→v2 migration (incl. Base64 wallpaper → IndexedDB, unsafe URL dropped), corrupt-data repair, site/category move & reorder persistence, URL validation & duplicates, full homepage render (8 categories / 48 tiles), 3 clock styles, live settings (icon size/shape, theme, layout order), widget add/hide/remove, weather (mocked API), news RSS+Atom parsing, to-do persistence, Idle Mode enter/Esc/click, all 13 settings sections render, syntax check of every file.

**Not tested in a real browser (no Brave in the build environment):** actual video decoding/looping, backdrop-filter visuals, native drag events, fullscreen, real API calls, and the whole tab-capture/offscreen audio pipeline. Please run the checklist in section 23 of your spec in Brave before relying on these.

## Implemented vs not
All sections of the spec are implemented with the limitations above. Not implemented: microphone/voice search (see above), widget resizing beyond three sizes, touch drag & drop.
